package pl.dock.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.io.FileOutputStream;

public class Icons {
    static final int S = 128;

    static File fileForPkg(Context c, String pkg) {
        String safe = pkg == null ? "unknown" : pkg.replace('.', '_');
        return new File(c.getFilesDir(), "icon_" + safe + ".png");
    }

    // legacy slot-based file (migration)
    static File file(Context c, int slot) {
        return new File(c.getFilesDir(), "icon_" + slot + ".png");
    }

    public static Bitmap forPackage(Context c, String pkg) {
        try {
            return rounded(drawableToBitmap(c.getPackageManager().getApplicationIcon(pkg)), false);
        } catch (Exception e) {
            return rounded(null, false);
        }
    }

    public static Bitmap forEntry(Context c, Prefs.AppEntry e) {
        Bitmap raw = null;
        try {
            if (e != null) {
                if ("file".equals(e.iconMode)) {
                    File f = fileForPkg(c, e.pkg);
                    if (f.exists()) {
                        raw = BitmapFactory.decodeFile(f.getAbsolutePath());
                    }
                } else if ("app".equals(e.iconMode) && e.iconPkg != null && e.iconPkg.length() > 0) {
                    raw = drawableToBitmap(c.getPackageManager().getApplicationIcon(e.iconPkg));
                }
                if (raw == null && e.pkg != null && e.pkg.length() > 0) {
                    raw = drawableToBitmap(c.getPackageManager().getApplicationIcon(e.pkg));
                }
            }
        } catch (Exception ignored) {
        }
        boolean glass = Prefs.isLiquidGlass(c);
        return rounded(raw, glass);
    }

    public static Bitmap forDisplaySlot(Context c, int slot) {
        String pkg = Prefs.displayPkg(c, slot);
        if (pkg == null || pkg.length() == 0) {
            return rounded(null, Prefs.isLiquidGlass(c));
        }
        Prefs.AppEntry e = Prefs.entryFor(c, pkg);
        return forEntry(c, e);
    }

    static Bitmap drawableToBitmap(Drawable d) {
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        d.setBounds(0, 0, S, S);
        d.draw(cv);
        return b;
    }

    static Bitmap rounded(Bitmap raw, boolean liquidGlass) {
        Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas oc = new Canvas(out);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = liquidGlass ? S * 0.28f : S * 0.225f;

        if (raw != null) {
            Bitmap sc = Bitmap.createScaledBitmap(raw, S, S, true);
            p.setShader(new BitmapShader(sc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            oc.drawRoundRect(new RectF(0, 0, S, S), r, r, p);
            p.setShader(null);

            if (liquidGlass) {
                // delikatny połysk (glass highlight)
                Paint hl = new Paint(Paint.ANTI_ALIAS_FLAG);
                hl.setStyle(Paint.Style.FILL);
                hl.setColor(0x33FFFFFF);
                oc.drawRoundRect(new RectF(S * 0.08f, S * 0.06f, S * 0.92f, S * 0.38f), r * 0.6f, r * 0.6f, hl);

                // cienka obwódka
                Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
                stroke.setStyle(Paint.Style.STROKE);
                stroke.setStrokeWidth(S * 0.03f);
                stroke.setColor(0x55FFFFFF);
                oc.drawRoundRect(new RectF(S * 0.02f, S * 0.02f, S * 0.98f, S * 0.98f), r, r, stroke);
            }
        } else {
            p.setColor(Color.parseColor("#2A3344"));
            oc.drawRoundRect(new RectF(0, 0, S, S), r, r, p);
        }
        return out;
    }

    public static boolean saveFromStream(Context c, String pkg, java.io.InputStream in1,
                                         java.io.InputStream in2) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in1, null, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= 512 && o.outHeight / (sample * 2) >= 512) {
                sample *= 2;
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap bmp = BitmapFactory.decodeStream(in2, null, o2);
            if (bmp == null) return false;
            int side = Math.min(bmp.getWidth(), bmp.getHeight());
            Bitmap sq = Bitmap.createBitmap(bmp,
                    (bmp.getWidth() - side) / 2, (bmp.getHeight() - side) / 2, side, side);
            Bitmap fin = Bitmap.createScaledBitmap(sq, 256, 256, true);
            FileOutputStream fo = new FileOutputStream(fileForPkg(c, pkg));
            fin.compress(Bitmap.CompressFormat.PNG, 100, fo);
            fo.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
