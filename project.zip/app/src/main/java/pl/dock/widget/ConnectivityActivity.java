package pl.dock.widget;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

// Panel łączności w stylu Centrum sterowania iPhone'a (okno obok docka, nie pełny ekran).
// Dotknięcie kafelka przełącza; długie dotknięcie otwiera odpowiednie ustawienia systemu.
public class ConnectivityActivity extends Activity {

    private boolean night;
    private Tile tWifi, tBt, tHot;
    private final Handler h = new Handler(Looper.getMainLooper());
    private BroadcastReceiver rc;
    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            update();
        }
    };

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle b) {
        night = Look.night(this);
        setTheme(android.R.style.Theme_Translucent_NoTitleBar);
        super.onCreate(b);
        Ui.dockWindow(getWindow(), this);
        build();
        update();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        finish();   // ponowne dotknięcie paska zamyka panel
    }

    private void build() {
        FrameLayout root = new FrameLayout(this);
        root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.popupBg(this, night));
        card.setPadding(dp(12), dp(12), dp(12), dp(8));
        card.setClickable(true);
        card.setElevation(dp(12));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        tWifi = new Tile(this, false);
        tBt = new Tile(this, false);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, dp(150), 1f);
        lp1.rightMargin = dp(6);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, dp(150), 1f);
        lp2.leftMargin = dp(6);
        row1.addView(tWifi, lp1);
        row1.addView(tBt, lp2);
        card.addView(row1);

        tHot = new Tile(this, true);
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(76));
        lp3.topMargin = dp(12);
        card.addView(tHot, lp3);

        TextView st = new TextView(this);
        st.setText("Ustawienia Docka");
        st.setTextSize(16);
        st.setTextColor(night ? 0xFF0A84FF : 0xFF007AFF);
        st.setGravity(Gravity.CENTER);
        st.setPadding(0, dp(12), 0, dp(8));
        st.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ConnectivityActivity.this, ConfigActivity.class));
                finish();
            }
        });
        card.addView(st);

        int w = Math.min(dp(430), Ui.windowWidth(this) - dp(24));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(w,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | (Ui.dockLeft(this) ? Gravity.START : Gravity.END));
        clp.setMargins(dp(8), dp(12), dp(8), dp(8));
        root.addView(card, clp);
        setContentView(root);

        tWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleWifi();
            }
        });
        tWifi.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Net.openWifiSettings(ConnectivityActivity.this);
                return true;
            }
        });
        tBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleBt();
            }
        });
        tBt.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Net.openBluetoothSettings(ConnectivityActivity.this);
                return true;
            }
        });
        tHot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleHotspot();
            }
        });
        tHot.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Net.openTetherSettings(ConnectivityActivity.this);
                return true;
            }
        });
    }

    // ---------------------------------------------------------------- akcje
    private void toggleWifi() {
        final boolean before = Net.wifiEnabled(this);
        boolean ok = Net.setWifi(this, !before);
        if (!ok) {
            Toast.makeText(this, "Radio nie pozwala przełączyć Wi-Fi – otwieram ustawienia",
                    Toast.LENGTH_LONG).show();
            Net.openWifiSettings(this);
            return;
        }
        // jeśli stan się nie zmienił, system zignorował polecenie
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (Net.wifiEnabled(ConnectivityActivity.this) == before) {
                    Toast.makeText(ConnectivityActivity.this,
                            "Wi-Fi nie zmienił stanu – otwieram ustawienia", Toast.LENGTH_LONG).show();
                    Net.openWifiSettings(ConnectivityActivity.this);
                }
            }
        }, 2500);
        scheduleRefresh();
    }

    private void toggleBt() {
        String mode = Prefs.btAction(this);
        if ("app".equals(mode)) {
            Net.openBluetoothApp(this);
            finish();
            return;
        }
        final boolean before = Net.bluetoothOn();
        boolean ok = Net.setBluetooth(!before);
        if (!ok && "auto".equals(mode)) {
            Toast.makeText(this, "Otwieram aplikację Bluetooth radia", Toast.LENGTH_SHORT).show();
            Net.openBluetoothApp(this);
            finish();
            return;
        }
        if ("auto".equals(mode)) {
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (Net.bluetoothOn() == before && !isFinishing()) {
                        Toast.makeText(ConnectivityActivity.this,
                                "Bluetooth sterowany przez radio – otwieram jego aplikację",
                                Toast.LENGTH_LONG).show();
                        Net.openBluetoothApp(ConnectivityActivity.this);
                        finish();
                    }
                }
            }, 2500);
        }
        scheduleRefresh();
    }

    private void toggleHotspot() {
        String r = Net.setTethering(this, !Net.tethering(this));
        if ("settings".equals(r)) {
            Toast.makeText(this, "Hotspotu nie da się przełączyć z aplikacji – otwieram "
                    + "ustawienia systemu", Toast.LENGTH_LONG).show();
        } else if ("fail".equals(r)) {
            Toast.makeText(this, "Nie udało się zmienić hotspotu", Toast.LENGTH_SHORT).show();
        }
        scheduleRefresh();
    }

    private void scheduleRefresh() {
        h.postDelayed(refresh, 700);
        h.postDelayed(refresh, 1800);
        h.postDelayed(refresh, 3500);
    }

    private void update() {
        boolean wEn = Net.wifiEnabled(this);
        boolean wCon = Net.wifiConnected(this);
        boolean bt = Net.bluetoothOn();
        boolean th = Net.tethering(this);
        int white = 0xFFFFFFFF;
        tWifi.set(wEn, 0xFF1C94FF, Icons.vector(this,
                wEn ? R.drawable.ic_wifi : R.drawable.ic_wifi_off, 128, white), "Wi-Fi",
                wCon ? "Połączono" : (wEn ? "Włączone" : "Wyłączone"));
        tBt.set(bt, 0xFF1C94FF, Icons.vector(this, R.drawable.ic_bt, 128, white), "Bluetooth",
                bt ? "Wł." : "Wył.");
        tHot.set(th, 0xFF30D158, Icons.tether(128, white, false), "Hotspot osobisty",
                th ? "Wł." : "Wył.");
        DockWidget.updateAll(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        rc = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                update();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        f.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
        f.addAction("android.net.conn.TETHER_STATE_CHANGED");
        registerReceiver(rc, f);
        update();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (rc != null) unregisterReceiver(rc);
        } catch (Exception ignored) {
        }
        rc = null;
        h.removeCallbacks(refresh);
    }

    // ---------------------------------------------------------------- kafelek (jak w iOS)
    private class Tile extends View {
        private final boolean wide;
        private boolean active;
        private int color = 0xFF1C94FF;
        private Bitmap icon;
        private String title = "";
        private String sub = "";
        private boolean pressed;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final float d = getResources().getDisplayMetrics().density;

        Tile(Context c, boolean wide) {
            super(c);
            this.wide = wide;
        }

        void set(boolean active, int color, Bitmap icon, String title, String sub) {
            this.active = active;
            this.color = color;
            this.icon = icon;
            this.title = title;
            this.sub = sub;
            setContentDescription(title + ", " + sub);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth();
            float hh = getHeight();
            float rad = wide ? hh / 2f : 34f * d;
            // tło kafelka
            p.setStyle(Paint.Style.FILL);
            p.setColor(night ? 0xF0606767 : 0xFFE4E4EA);
            r.set(0, 0, w, hh);
            cv.drawRoundRect(r, rad, rad, p);
            if (pressed) {
                p.setColor(0x22FFFFFF);
                cv.drawRoundRect(r, rad, rad, p);
            }
            // pierścień z poświatą od lewego górnego rogu
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.6f * d);
            p.setShader(new LinearGradient(0, 0, w, hh,
                    new int[]{0xCCFFFFFF, 0x55FFFFFF, 0x22FFFFFF, 0x44FFFFFF},
                    new float[]{0f, 0.35f, 0.75f, 1f}, Shader.TileMode.CLAMP));
            r.set(d, d, w - d, hh - d);
            cv.drawRoundRect(r, rad - d, rad - d, p);
            p.setShader(null);

            // kółko z ikoną
            float cd = 50f * d;
            float cx;
            float cy;
            if (wide) {
                cx = 20f * d + cd / 2f;
                cy = hh / 2f;
            } else {
                cx = 18f * d + cd / 2f;
                cy = 18f * d + cd / 2f;
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(active ? color : 0xFF7E8686);
            cv.drawCircle(cx, cy, cd / 2f, p);
            if (icon != null) {
                float is = 28f * d;
                r.set(cx - is / 2f, cy - is / 2f, cx + is / 2f, cy + is / 2f);
                p.setAlpha(255);
                cv.drawBitmap(icon, null, r, p);
            }

            // teksty
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextAlign(Paint.Align.LEFT);
            float sd = getResources().getDisplayMetrics().scaledDensity;
            int tc = night ? 0xFFFFFFFF : 0xFF111114;
            int sc = night ? 0xFFC9CFCF : 0xFF6C6C70;
            if (wide) {
                float tx = 20f * d + cd + 14f * d;
                p.setColor(tc);
                p.setTextSize(19f * sd);
                cv.drawText(title, tx, hh / 2f - 4f * d, p);
                p.setTypeface(Typeface.DEFAULT);
                p.setColor(sc);
                p.setTextSize(16f * sd);
                cv.drawText(sub, tx, hh / 2f + 20f * d, p);
            } else {
                p.setColor(tc);
                p.setTextSize(19f * sd);
                cv.drawText(title, 18f * d, hh - 40f * d, p);
                p.setTypeface(Typeface.DEFAULT);
                p.setColor(sc);
                p.setTextSize(16f * sd);
                cv.drawText(sub, 18f * d, hh - 16f * d, p);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                pressed = true;
                invalidate();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                pressed = false;
                invalidate();
            }
            return super.onTouchEvent(e);
        }
    }
}
