package pl.dock.widget;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Prefs {
    public static final int DISPLAY_SLOTS = 4; // zawsze 4 na widżecie (3 dynamiczne + CarPlay)

    static final String DEFAULT_PINNED = "com.google.android.projection.gearhead";
    static final String[] DEFAULT_APPS = {
            "com.waze", "com.brave.browser", "com.android.dialer", "com.openai.chatgpt"
    };

    public static class AppEntry {
        public String pkg;
        public String iconMode; // "default" | "file" | "app"
        public String iconPkg;

        public AppEntry(String pkg, String iconMode, String iconPkg) {
            this.pkg = pkg == null ? "" : pkg;
            this.iconMode = iconMode == null ? "default" : iconMode;
            this.iconPkg = iconPkg == null ? "" : iconPkg;
        }

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("pkg", pkg);
            o.put("mode", iconMode);
            o.put("iconpkg", iconPkg);
            return o;
        }

        static AppEntry fromJson(JSONObject o) {
            return new AppEntry(
                    o.optString("pkg", ""),
                    o.optString("mode", "default"),
                    o.optString("iconpkg", "")
            );
        }
    }

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("dock", Context.MODE_PRIVATE);
    }

    public static List<AppEntry> getApps(Context c) {
        String raw = sp(c).getString("apps_json", null);
        List<AppEntry> list = new ArrayList<AppEntry>();
        if (raw != null && raw.length() > 0) {
            try {
                JSONArray arr = new JSONArray(raw);
                for (int i = 0; i < arr.length(); i++) {
                    list.add(AppEntry.fromJson(arr.getJSONObject(i)));
                }
            } catch (Exception ignored) {
            }
        }
        if (list.isEmpty()) {
            for (String p : DEFAULT_APPS) {
                list.add(new AppEntry(p, "default", ""));
            }
        }
        return list;
    }

    public static void setApps(Context c, List<AppEntry> apps) {
        try {
            JSONArray arr = new JSONArray();
            for (AppEntry e : apps) {
                arr.put(e.toJson());
            }
            sp(c).edit().putString("apps_json", arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static void addApp(Context c, String pkg) {
        List<AppEntry> apps = getApps(c);
        for (AppEntry e : apps) {
            if (e.pkg.equals(pkg)) return;
        }
        apps.add(new AppEntry(pkg, "default", ""));
        setApps(c, apps);
    }

    public static void removeApp(Context c, int index) {
        List<AppEntry> apps = getApps(c);
        if (index < 0 || index >= apps.size()) return;
        String pkg = apps.get(index).pkg;
        apps.remove(index);
        setApps(c, apps);
        clearUsage(c, pkg);
    }

    public static void updateAppIcon(Context c, int index, String mode, String iconPkg) {
        List<AppEntry> apps = getApps(c);
        if (index < 0 || index >= apps.size()) return;
        AppEntry e = apps.get(index);
        e.iconMode = mode;
        e.iconPkg = iconPkg == null ? "" : iconPkg;
        setApps(c, apps);
    }

    public static void moveApp(Context c, int from, int to) {
        List<AppEntry> apps = getApps(c);
        if (from < 0 || from >= apps.size() || to < 0 || to >= apps.size()) return;
        AppEntry e = apps.remove(from);
        apps.add(to, e);
        setApps(c, apps);
    }

    public static String pinnedPkg(Context c) {
        return sp(c).getString("pinned", DEFAULT_PINNED);
    }

    public static void setPinnedPkg(Context c, String pkg) {
        sp(c).edit().putString("pinned", pkg).apply();
    }

    public static String rankingMode(Context c) {
        return sp(c).getString("ranking", "recent");
    }

    public static void setRankingMode(Context c, String mode) {
        sp(c).edit().putString("ranking", mode).apply();
    }

    public static String themeStyle(Context c) {
        return sp(c).getString("theme_style", "liquid_glass");
    }

    public static void setThemeStyle(Context c, String style) {
        sp(c).edit().putString("theme_style", style).apply();
    }

    public static String themeMode(Context c) {
        return sp(c).getString("theme_mode", "system");
    }

    public static void setThemeMode(Context c, String mode) {
        sp(c).edit().putString("theme_mode", mode).apply();
    }

    public static boolean isNight(Context c) {
        String mode = themeMode(c);
        if ("day".equals(mode)) return false;
        if ("night".equals(mode)) return true;
        int night = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return night == Configuration.UI_MODE_NIGHT_YES;
    }

    public static boolean isLiquidGlass(Context c) {
        return "liquid_glass".equals(themeStyle(c));
    }

    public static boolean showVoltage(Context c) {
        return sp(c).getBoolean("voltage", false);
    }

    public static void setShowVoltage(Context c, boolean v) {
        sp(c).edit().putBoolean("voltage", v).apply();
    }

    public static void recordLaunch(Context c, String pkg) {
        if (pkg == null || pkg.length() == 0) return;
        SharedPreferences p = sp(c);
        long now = System.currentTimeMillis();
        int count = p.getInt("uc_" + pkg, 0) + 1;
        p.edit()
                .putInt("uc_" + pkg, count)
                .putLong("ut_" + pkg, now)
                .apply();
    }

    public static long lastUsed(Context c, String pkg) {
        return sp(c).getLong("ut_" + pkg, 0L);
    }

    public static int useCount(Context c, String pkg) {
        return sp(c).getInt("uc_" + pkg, 0);
    }

    static void clearUsage(Context c, String pkg) {
        sp(c).edit().remove("uc_" + pkg).remove("ut_" + pkg).apply();
    }

    public static List<String> topThree(Context c) {
        final String pinned = pinnedPkg(c);
        List<AppEntry> apps = getApps(c);
        List<AppEntry> candidates = new ArrayList<AppEntry>();
        for (AppEntry e : apps) {
            if (e.pkg == null || e.pkg.length() == 0) continue;
            if (e.pkg.equals(pinned)) continue;
            candidates.add(e);
        }

        final boolean recent = "recent".equals(rankingMode(c));
        final Context ctx = c;
        Collections.sort(candidates, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                if (recent) {
                    long ta = lastUsed(ctx, a.pkg);
                    long tb = lastUsed(ctx, b.pkg);
                    if (ta != tb) return Long.compare(tb, ta);
                } else {
                    int ca = useCount(ctx, a.pkg);
                    int cb = useCount(ctx, b.pkg);
                    if (ca != cb) return Integer.compare(cb, ca);
                }
                return 0;
            }
        });

        List<String> out = new ArrayList<String>();
        for (AppEntry e : candidates) {
            if (out.size() >= 3) break;
            out.add(e.pkg);
        }
        if (out.size() < 3) {
            for (AppEntry e : apps) {
                if (out.size() >= 3) break;
                if (e.pkg.equals(pinned)) continue;
                if (!out.contains(e.pkg)) out.add(e.pkg);
            }
        }
        return out;
    }

    public static AppEntry entryFor(Context c, String pkg) {
        for (AppEntry e : getApps(c)) {
            if (e.pkg.equals(pkg)) return e;
        }
        return new AppEntry(pkg, "default", "");
    }

    public static String displayPkg(Context c, int slot) {
        if (slot == 3) return pinnedPkg(c);
        List<String> top = topThree(c);
        if (slot >= 0 && slot < top.size()) return top.get(slot);
        return "";
    }
}
