package pl.dock.widget;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;

import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.Locale;

// Stan BT / WiFi / tetheringu tabletu
public class Net {

    public static boolean bluetoothOn() {
        try {
            BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
            return a != null && a.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    private static WifiManager wm(Context c) {
        return (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }

    public static boolean wifiEnabled(Context c) {
        try {
            WifiManager w = wm(c);
            return w != null && w.isWifiEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    public static boolean wifiConnected(Context c) {
        try {
            if (!wifiEnabled(c)) return false;
            ConnectivityManager cm = (ConnectivityManager)
                    c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return false;
        }
    }

    // hotspot WiFi (ukryte API przez refleksję); null = brak odczytu
    public static Boolean apEnabled(Context c) {
        try {
            Method m = WifiManager.class.getDeclaredMethod("isWifiApEnabled");
            m.setAccessible(true);
            return (Boolean) m.invoke(wm(c));
        } catch (Throwable t) {
            return null;
        }
    }

    public static String[] tetheredIfaces(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                    c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Method m = ConnectivityManager.class.getDeclaredMethod("getTetheredIfaces");
            m.setAccessible(true);
            return (String[]) m.invoke(cm);
        } catch (Throwable t) {
            return null;
        }
    }

    // czy działa interfejs typowy dla tetheringu (hotspot, USB, BT)
    public static boolean tetherInterfaceUp() {
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                String n = ni.getName().toLowerCase(Locale.US);
                boolean nameHit = n.startsWith("ap") || n.startsWith("softap")
                        || n.startsWith("swlan") || n.startsWith("rndis")
                        || n.startsWith("bt-pan") || n.startsWith("usb") || n.startsWith("ncm");
                Enumeration<InetAddress> ad = ni.getInetAddresses();
                while (ad.hasMoreElements()) {
                    InetAddress a = ad.nextElement();
                    if (!(a instanceof Inet4Address)) continue;
                    String h = a.getHostAddress();
                    if (nameHit) return true;
                    if (h.equals("192.168.43.1") || h.equals("192.168.42.129")
                            || h.equals("192.168.44.1")) return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    public static boolean tethering(Context c) {
        Boolean ap = apEnabled(c);
        if (ap != null && ap) return true;
        String[] t = tetheredIfaces(c);
        if (t != null && t.length > 0) return true;
        return tetherInterfaceUp();
    }

    public static String interfaces() {
        StringBuilder b = new StringBuilder();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                b.append("  ").append(ni.getName()).append(ni.isUp() ? " [up]" : " [down]");
                Enumeration<InetAddress> ad = ni.getInetAddresses();
                while (ad.hasMoreElements()) {
                    InetAddress a = ad.nextElement();
                    if (a instanceof Inet4Address) b.append(" ").append(a.getHostAddress());
                }
                b.append("\n");
            }
        } catch (Throwable t) {
            b.append("  brak odczytu\n");
        }
        return b.toString();
    }
}
