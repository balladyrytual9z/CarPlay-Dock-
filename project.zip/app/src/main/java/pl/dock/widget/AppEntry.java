package pl.dock.widget;

import org.json.JSONObject;

public class AppEntry {
    public long id;            // 0 = aplikacja CarPlay (przypięta na dole)
    public String pkg = "";
    public String mode = "default";   // default | file | app
    public String iconPkg = "";
    public int count;
    public long last;

    public String key() {
        return id == 0 ? "cp" : "e" + id;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("pkg", pkg);
            o.put("mode", mode);
            o.put("iconPkg", iconPkg);
            o.put("count", count);
            o.put("last", last);
        } catch (Exception ignored) {
        }
        return o;
    }

    public static AppEntry fromJson(JSONObject o) {
        AppEntry e = new AppEntry();
        e.id = o.optLong("id", 0);
        e.pkg = o.optString("pkg", "");
        e.mode = o.optString("mode", "default");
        e.iconPkg = o.optString("iconPkg", "");
        e.count = o.optInt("count", 0);
        e.last = o.optLong("last", 0);
        return e;
    }
}
