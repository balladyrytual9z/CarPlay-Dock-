package pl.dock.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

// Kropki stron aplikacji (jak w CarPlay)
public class PageDots extends View {

    private int count;
    private float active;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;
    private int base = 0x00FFFFFF;

    public PageDots(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    // na jasnym tle kropki są ciemne
    public void setLight(boolean light) {
        base = light ? 0x00000000 : 0x00FFFFFF;
        invalidate();
    }

    public void set(int count, float active) {
        this.count = count;
        this.active = active;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        if (count <= 1) return;
        float r = 5f * d;
        float pitch = 20f * d;
        float total = pitch * (count - 1);
        float x0 = getWidth() / 2f - total / 2f;
        float cy = getHeight() / 2f;
        for (int i = 0; i < count; i++) {
            float near = Math.max(0f, 1f - Math.abs(i - active));
            int a = 90 + (int) (150 * near);
            p.setColor((a << 24) | base);
            cv.drawCircle(x0 + i * pitch, cy, r, p);
        }
    }
}
