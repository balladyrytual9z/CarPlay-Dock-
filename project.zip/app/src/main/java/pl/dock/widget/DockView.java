package pl.dock.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

// Dock w launcherze: te same wymiary co widżet (zegar, statusy, napięcie, 4 ikony, przycisk dolny).
// Rysowany jednym widokiem; odświeżany tylko przy zmianie danych.
public class DockView extends View {

    public interface Listener {
        void onHeader();

        void onApp(int index);   // 0..2 górne aplikacje, 3 = CarPlay

        void onBottom();
    }

    private static final int HEADER = 5;
    private static final int BOTTOM = 4;

    private final float d;
    private Listener listener;
    private boolean night = true, glass, showVolt;
    private String clock = "--:--";
    private String volt = "";
    private final Bitmap[] icons = new Bitmap[4];
    private Bitmap bWifi, bTether, bBt, bBattery, bGrid, bCp;
    private boolean showCp = true;
    private float bottomT;
    private Drawable bg;
    private int bgRes = -1;
    private int fg = 0xFFFFFFFF;

    private final Paint clockPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint voltPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint homePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private int pressed = -1;
    private float downX, downY;
    private final int slop;

    public DockView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        clockPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        clockPaint.setTextSize(19f * c.getResources().getDisplayMetrics().scaledDensity);
        clockPaint.setTextAlign(Paint.Align.CENTER);
        voltPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        voltPaint.setTextSize(12f * c.getResources().getDisplayMetrics().scaledDensity);
        homePaint.setStyle(Paint.Style.STROKE);
        homePaint.setStrokeWidth(3.2f * d);
        setContentDescription("Dock");
    }

    public void setListener(Listener l) {
        listener = l;
    }

    // szerokość widoku: panel 65 dp + po 6 dp odstępu z obu stron
    public static int widthDp() {
        return Ui.DOCK_OFFSET_DP;
    }

    public void setData(boolean night, boolean glass, String clock, StatusCenter.Snap s,
                        boolean showVolt, Bitmap[] ic) {
        this.night = night;
        this.glass = glass;
        this.clock = clock;
        this.showVolt = showVolt;
        this.volt = s.volt.length() > 0 ? s.volt : "-- V";
        fg = night ? 0xFFFFFFFF : 0xFF111111;
        int dim = (fg & 0x00FFFFFF) | 0x66000000;
        int dimmer = (fg & 0x00FFFFFF) | 0x40000000;
        Context c = getContext();
        bWifi = Icons.vector(c, s.wifiEn ? R.drawable.ic_wifi : R.drawable.ic_wifi_off, 96,
                s.wifiCon ? fg : (s.wifiEn ? dim : dimmer));
        bTether = Icons.tether(96, s.tether ? fg : dimmer, false);
        bBt = Icons.vector(c, R.drawable.ic_bt, 96, s.bt ? fg : dimmer);
        bBattery = Icons.vector(c, R.drawable.ic_battery, 96, fg);
        bGrid = Icons.vector(c, R.drawable.ic_grid, 128, fg);
        showCp = Prefs.cpShow(c);
        bCp = Icons.carplayMark(96, CarplayState.color(s.cp, fg));
        for (int i = 0; i < 4; i++) icons[i] = ic != null && i < ic.length ? ic[i] : null;
        int res = Look.bg(glass, night);
        if (res != bgRes) {
            bgRes = res;
            bg = c.getDrawable(res).mutate();
        }
        clockPaint.setColor(fg);
        voltPaint.setColor(fg);
        homePaint.setColor(fg);
        invalidate();
    }

    // 0 = siatka, 1 = symbol ekranu głównego
    public void setBottomProgress(float t) {
        t = Math.max(0f, Math.min(1f, t));
        if (Math.abs(t - bottomT) < 0.004f) return;
        bottomT = t;
        invalidate();
    }

    // ------------------------------------------------------------ geometria (dp -> px)
    private float panelL() {
        return 6f * d;
    }

    private float panelT() {
        return 6f * d;
    }

    private float panelR() {
        return panelL() + 65f * d;
    }

    private float panelB() {
        return getHeight() - 6f * d;
    }

    private float cx() {
        return panelL() + 32.5f * d;
    }

    private float iconTop(int i) {
        return panelT() + (164f + 54f * i) * d;
    }

    private float bottomCy() {
        return panelB() - 32f * d;
    }

    @Override
    protected void onDraw(Canvas cv) {
        if (bg != null) {
            bg.setBounds((int) panelL(), (int) panelT(), (int) panelR(), (int) panelB());
            bg.draw(cv);
        }
        float cx = cx();
        float top = panelT();

        // zegar
        float cy = top + 24f * d;
        cv.drawText(clock, cx, cy - (clockPaint.descent() + clockPaint.ascent()) / 2f, clockPaint);

        // WiFi, tethering, Bluetooth
        float sy = top + 50f * d;
        float is = 16f * d;
        float x0 = cx - 27f * d;
        drawIcon(cv, bWifi, x0, sy - is / 2f, is, is, 255);
        drawIcon(cv, bTether, x0 + 19f * d, sy - is / 2f, is, is, 255);
        drawIcon(cv, bBt, x0 + 38f * d, sy - is / 2f, is, is, 255);

        // napięcie
        if (showVolt) {
            float py = top + 76f * d;
            float tw = voltPaint.measureText(volt);
            float start = cx - (24f * d + 3f * d + tw) / 2f;
            drawIcon(cv, bBattery, start + 2f * d, py - 10f * d, 20f * d, 20f * d, 255);
            cv.drawText(volt, start + 27f * d, py - (voltPaint.descent() + voltPaint.ascent()) / 2f,
                    voltPaint);
        }

        // status CarPlay (pod napięciem; gdy napięcie ukryte, wyżej)
        if (showCp) {
            float cpy = top + (showVolt ? 102f : 76f) * d;
            drawIcon(cv, bCp, cx - 10f * d, cpy - 10f * d, 20f * d, 20f * d, 255);
        }

        // ikony: 3 górne + CarPlay
        float sz = 42f * d;
        for (int i = 0; i < 4; i++) {
            Bitmap b = icons[i];
            if (b == null) continue;
            drawIcon(cv, b, cx - sz / 2f, iconTop(i), sz, sz, pressed == i ? 150 : 255);
        }

        // przycisk dolny: siatka -> symbol ekranu głównego
        float by = bottomCy();
        int pa = pressed == BOTTOM ? 150 : 255;
        float g = 20f * d;
        if (bottomT < 0.999f) {
            drawIcon(cv, bGrid, cx - g / 2f, by - g / 2f, g, g, (int) (pa * (1f - bottomT)));
        }
        if (bottomT > 0.001f) {
            homePaint.setAlpha((int) (pa * bottomT));
            rect.set(cx - g / 2f, by - g / 2f, cx + g / 2f, by + g / 2f);
            cv.drawRoundRect(rect, 6f * d, 6f * d, homePaint);
        }
    }

    private void drawIcon(Canvas cv, Bitmap b, float l, float t, float w, float h, int alpha) {
        if (b == null || alpha <= 0) return;
        bmpPaint.setAlpha(alpha);
        rect.set(l, t, l + w, t + h);
        cv.drawBitmap(b, null, rect, bmpPaint);
    }

    // ------------------------------------------------------------ dotyk
    private int hit(float x, float y) {
        if (x < panelL() || x > panelR()) return -1;
        float top = panelT();
        if (y >= top && y < top + 164f * d) return HEADER;
        float sz = 42f * d;
        float m = 6f * d;
        for (int i = 0; i < 4; i++) {
            float t = iconTop(i);
            if (y >= t - m && y <= t + sz + m) return i;
        }
        float by = bottomCy();
        if (Math.abs(y - by) <= 28f * d) return BOTTOM;
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                pressed = hit(downX, downY);
                if (pressed < 0) return false;
                if (pressed < 4 && icons[pressed] == null) {
                    pressed = -1;
                    return false;
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (pressed >= 0 && (Math.abs(e.getX() - downX) > slop
                        || Math.abs(e.getY() - downY) > slop)) {
                    pressed = -1;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                int p = pressed;
                pressed = -1;
                invalidate();
                if (p >= 0 && listener != null) {
                    if (p == HEADER) {
                        listener.onHeader();
                    } else if (p == BOTTOM) {
                        listener.onBottom();
                    } else {
                        listener.onApp(p);
                    }
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                pressed = -1;
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
