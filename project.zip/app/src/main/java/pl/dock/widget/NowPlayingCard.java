package pl.dock.widget;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;

// Widżet "Odtwarzane" jak w CarPlay: okładka, tytuł, wykonawca, pasek postępu i sterowanie.
// Dotknięcie okładki lub tytułu otwiera pełny ekran odtwarzania.
public class NowPlayingCard extends View implements MediaHub.Listener {

    private final float d;
    private MediaHub.Track t = new MediaHub.Track();
    private boolean night = true;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (t.playing() && isAttachedToWindow()) h.postDelayed(this, 1000);
        }
    };
    private int pressed = -1;   // 0 prev, 1 play, 2 next

    public NowPlayingCard(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setContentDescription("Odtwarzane");
    }

    public void setNight(boolean n) {
        if (n == night) return;
        night = n;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        MediaHub.get().attach(getContext(), this);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h.removeCallbacks(tick);
        MediaHub.get().detach(this);
    }

    @Override
    public void onTrack(MediaHub.Track track) {
        t = track;
        h.removeCallbacks(tick);
        if (t.playing()) h.postDelayed(tick, 1000);
        invalidate();
    }

    private float scaledSp(float sp) {
        return sp * getResources().getDisplayMetrics().scaledDensity;
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth();
        float hgt = getHeight();
        float pad = 16f * d;
        int fg = night ? 0xFFFFFFFF : 0xFF111114;
        int sub = night ? 0xFF9A9AA0 : 0xFF6C6C70;
        boolean access = MediaHub.accessGranted(getContext());
        boolean data = t.hasData();

        // okładka
        float artSide = Math.min(w - 2 * pad, hgt - 196f * d);
        float y = pad;
        if (artSide >= 56f * d) {
            float ax = w / 2f - artSide / 2f;
            r.set(ax, y, ax + artSide, y + artSide);
            if (t.art != null) {
                Bitmap b = t.art;
                paint.setFilterBitmap(true);
                android.graphics.BitmapShader sh = new android.graphics.BitmapShader(b,
                        android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP);
                android.graphics.Matrix m = new android.graphics.Matrix();
                float sc = Math.max(artSide / b.getWidth(), artSide / b.getHeight());
                m.setScale(sc, sc);
                m.postTranslate(ax - (b.getWidth() * sc - artSide) / 2f,
                        y - (b.getHeight() * sc - artSide) / 2f);
                sh.setLocalMatrix(m);
                paint.setShader(sh);
                cv.drawRoundRect(r, 14f * d, 14f * d, paint);
                paint.setShader(null);
            } else {
                PlayGlyphs.artPlaceholder(cv, r, 14f * d, night);
            }
            y += artSide + 14f * d;
        }

        // tytuł i wykonawca
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(scaledSp(20));
        text.setColor(fg);
        String title;
        String artist;
        if (!access) {
            title = "Włącz dostęp do powiadomień";
            artist = "Dotknij, aby otworzyć ustawienia";
        } else if (!data) {
            title = "Odtwarzanie wyłączone";
            artist = "";
        } else {
            title = t.title.length() > 0 ? t.title : "Odtwarzane";
            artist = t.artist;
        }
        cv.drawText(TextUtils.ellipsize(title, text, w - 2 * pad, TextUtils.TruncateAt.END).toString(),
                w / 2f, y + 22f * d, text);
        text.setTypeface(Typeface.DEFAULT);
        text.setTextSize(scaledSp(16));
        text.setColor(sub);
        cv.drawText(TextUtils.ellipsize(artist, text, w - 2 * pad, TextUtils.TruncateAt.END).toString(),
                w / 2f, y + 46f * d, text);

        // pasek postępu
        float py = hgt - 76f * d;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(night ? 0x33FFFFFF : 0x22000000);
        r.set(pad, py, w - pad, py + 5f * d);
        cv.drawRoundRect(r, 3f * d, 3f * d, paint);
        if (t.duration > 0 && data) {
            float f = Math.max(0f, Math.min(1f, t.position() / (float) t.duration));
            paint.setColor(night ? 0xCCFFFFFF : 0xCC111114);
            r.set(pad, py, pad + (w - 2 * pad) * f, py + 5f * d);
            cv.drawRoundRect(r, 3f * d, 3f * d, paint);
        }

        // sterowanie
        float cy = hgt - 34f * d;
        float step = w / 4f;
        boolean on = access && data;
        paint.setColor(fg);
        paint.setAlpha(on ? (pressed == 0 ? 140 : 255) : 80);
        PlayGlyphs.skip(cv, w / 2f - step, cy, 30f * d, false, paint);
        paint.setColor(fg);
        paint.setAlpha(on ? (pressed == 2 ? 140 : 255) : 80);
        PlayGlyphs.skip(cv, w / 2f + step, cy, 30f * d, true, paint);
        paint.setColor(fg);
        paint.setAlpha(on ? (pressed == 1 ? 140 : 255) : 80);
        if (t.playing()) {
            PlayGlyphs.pause(cv, w / 2f, cy, 34f * d, paint);
        } else {
            PlayGlyphs.play(cv, w / 2f, cy, 34f * d, paint);
        }
        paint.setAlpha(255);
    }

    private int region(float x, float y) {
        float hgt = getHeight();
        float w = getWidth();
        if (y > hgt - 66f * d) {
            if (x < w * 0.38f) return 0;
            if (x > w * 0.62f) return 2;
            return 1;
        }
        return 3;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pressed = region(e.getX(), e.getY());
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                int p = pressed;
                pressed = -1;
                invalidate();
                if (p >= 0 && p == region(e.getX(), e.getY())) act(p);
                return true;
            case MotionEvent.ACTION_CANCEL:
                pressed = -1;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void act(int p) {
        Context c = getContext();
        if (!MediaHub.accessGranted(c)) {
            openAccessSettings(c);
            return;
        }
        if (p == 0) {
            MediaHub.get().prev();
        } else if (p == 1) {
            MediaHub.get().toggle();
        } else if (p == 2) {
            MediaHub.get().next();
        } else {
            Intent i = new Intent(c, NowPlayingActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        }
    }

    public static void openAccessSettings(Context c) {
        try {
            Intent i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            try {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            } catch (Throwable ignored) {
            }
        }
    }
}
