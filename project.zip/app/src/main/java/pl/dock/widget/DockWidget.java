package pl.dock.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.BatteryManager;
import android.view.View;
import java.util.Locale;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.widget.RemoteViews;

public class DockWidget extends AppWidgetProvider {

    private static final int ON_LIGHT = 0xFF1A1A1A;
    private static final int OFF_LIGHT = 0x661A1A1A;
    private static final int ON_DARK = 0xFFFFFFFF;
    private static final int OFF_DARK = 0x55FFFFFF;
    private static final int[] APP_IDS = {R.id.app1, R.id.app2, R.id.app3, R.id.app4};

    public static final String ACTION_LAUNCH = "pl.dock.widget.ACTION_LAUNCH";
    public static final String EXTRA_PKG = "pkg";
    public static final String EXTRA_SLOT = "slot";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        StatusService.start(context);
        RemoteViews rv = build(context);
        for (int id : ids) {
            manager.updateAppWidget(id, rv);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (ACTION_LAUNCH.equals(intent.getAction())) {
            String pkg = intent.getStringExtra(EXTRA_PKG);
            if (pkg != null && pkg.length() > 0) {
                Prefs.recordLaunch(context, pkg);
                Intent launch = context.getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        context.startActivity(launch);
                    } catch (Exception ignored) {
                    }
                }
                updateAll(context);
            }
            return;
        }
        super.onReceive(context, intent);
    }

    public static void updateAll(Context context) {
        AppWidgetManager m = AppWidgetManager.getInstance(context);
        int[] ids = m.getAppWidgetIds(new ComponentName(context, DockWidget.class));
        if (ids == null || ids.length == 0) return;
        m.updateAppWidget(ids, build(context));
    }

    private static RemoteViews build(Context c) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dock_widget);

        boolean night = Prefs.isNight(c);
        boolean glass = Prefs.isLiquidGlass(c);

        // tło
        if (glass) {
            rv.setInt(R.id.root, "setBackgroundResource",
                    night ? R.drawable.dock_bg_glass_night : R.drawable.dock_bg_glass_day);
        } else {
            rv.setInt(R.id.root, "setBackgroundResource",
                    night ? R.drawable.dock_bg_classic_night : R.drawable.dock_bg_classic_day);
        }

        int textColor = night ? Color.WHITE : Color.parseColor("#1A1A1A");
        int on = night ? ON_DARK : ON_LIGHT;
        int off = night ? OFF_DARK : OFF_LIGHT;

        rv.setTextColor(R.id.clock, textColor);
        rv.setTextColor(R.id.volt, textColor);
        rv.setInt(R.id.wifi, "setColorFilter", wifiConnected(c) ? on : off);
        rv.setInt(R.id.bt, "setColorFilter", bluetoothOn() ? on : off);
        rv.setInt(R.id.grid, "setColorFilter", on);

        for (int i = 0; i < APP_IDS.length; i++) {
            String pkg = Prefs.displayPkg(c, i);
            rv.setImageViewBitmap(APP_IDS[i], Icons.forDisplaySlot(c, i));

            Intent launch = new Intent(c, DockWidget.class);
            launch.setAction(ACTION_LAUNCH);
            launch.putExtra(EXTRA_PKG, pkg);
            launch.putExtra(EXTRA_SLOT, i);
            rv.setOnClickPendingIntent(APP_IDS[i], PendingIntent.getBroadcast(
                    c, 100 + i, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        }

        Intent cfg = new Intent(c, ConfigActivity.class);
        cfg.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        rv.setOnClickPendingIntent(R.id.header, PendingIntent.getActivity(
                c, 20, cfg, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        if (Prefs.showVoltage(c)) {
            rv.setViewVisibility(R.id.power_row, View.VISIBLE);
            rv.setTextViewText(R.id.volt, voltage(c));
        } else {
            rv.setViewVisibility(R.id.power_row, View.GONE);
        }

        Intent all = new Intent(Intent.ACTION_ALL_APPS);
        if (all.resolveActivity(c.getPackageManager()) == null) {
            all = new Intent(Intent.ACTION_MAIN);
            all.addCategory(Intent.CATEGORY_HOME);
        }
        all.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        rv.setOnClickPendingIntent(R.id.grid, PendingIntent.getActivity(
                c, 10, all, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return rv;
    }

    private static boolean bluetoothOn() {
        try {
            BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
            return a != null && a.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    private static boolean wifiConnected(Context c) {
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm == null || !wm.isWifiEnabled()) return false;
            ConnectivityManager cm = (ConnectivityManager)
                    c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return false;
        }
    }

    private static String voltage(Context c) {
        try {
            Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int mv = b == null ? 0 : b.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
            if (mv <= 0) return "-- V";
            float v = mv > 100 ? mv / 1000f : mv;
            return String.format(new Locale("pl"), "%.2f V", v);
        } catch (Exception e) {
            return "-- V";
        }
    }
}
