package pl.dock.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;

import java.util.List;

public class DockWidget extends AppWidgetProvider {

    private static final int[] TOP_IDS = {R.id.app1, R.id.app2, R.id.app3};

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        StatusService.start(context);
        RemoteViews rv = build(context);
        for (int id : ids) {
            manager.updateAppWidget(id, rv);
        }
    }

    public static void updateAll(Context context) {
        AppWidgetManager m = AppWidgetManager.getInstance(context);
        int[] ids = m.getAppWidgetIds(new ComponentName(context, DockWidget.class));
        if (ids == null || ids.length == 0) return;
        m.updateAppWidget(ids, build(context));
    }

    private static PendingIntent launchIntent(Context c, AppEntry e, int req) {
        Intent i = new Intent(c, LaunchReceiver.class);
        i.setData(Uri.parse("dock://launch/" + e.key()));
        i.putExtra("id", e.id);
        return PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static RemoteViews build(Context c) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.dock_widget);

        // wygląd: styl + tryb dzienny/nocny
        boolean night = Look.night(c);
        boolean glass = "glass".equals(Prefs.style(c));
        int fg = night ? 0xFFFFFFFF : 0xFF111111;
        int dim = (fg & 0x00FFFFFF) | 0x66000000;
        int dimmer = (fg & 0x00FFFFFF) | 0x40000000;
        rv.setInt(R.id.root, "setBackgroundResource", Look.bg(glass, night));
        rv.setTextColor(R.id.clock, fg);
        rv.setTextColor(R.id.volt, fg);
        rv.setInt(R.id.battery, "setColorFilter", fg);
        rv.setInt(R.id.grid, "setColorFilter", fg);

        // WiFi: połączone / włączone bez połączenia / wyłączone
        boolean wEn = Net.wifiEnabled(c);
        boolean wCon = Net.wifiConnected(c);
        rv.setImageViewResource(R.id.wifi, wEn ? R.drawable.ic_wifi : R.drawable.ic_wifi_off);
        rv.setInt(R.id.wifi, "setColorFilter", wCon ? fg : (wEn ? dim : dimmer));
        // tethering
        rv.setInt(R.id.tether, "setColorFilter", Net.tethering(c) ? fg : dimmer);
        // Bluetooth
        rv.setInt(R.id.bt, "setColorFilter", Net.bluetoothOn() ? fg : dimmer);

        // 3 górne aplikacje (wg ostatniego / najczęstszego użycia)
        List<AppEntry> top = Prefs.top(c, 3);
        for (int i = 0; i < TOP_IDS.length; i++) {
            if (i < top.size()) {
                AppEntry e = top.get(i);
                rv.setViewVisibility(TOP_IDS[i], View.VISIBLE);
                rv.setImageViewBitmap(TOP_IDS[i], Icons.forEntry(c, e));
                rv.setOnClickPendingIntent(TOP_IDS[i], launchIntent(c, e, i));
            } else {
                // INVISIBLE, żeby CarPlay został na swoim miejscu
                rv.setViewVisibility(TOP_IDS[i], View.INVISIBLE);
            }
        }

        // CarPlay: 4. ikona
        AppEntry cp = Prefs.carplay(c);
        rv.setImageViewBitmap(R.id.carplay, Icons.forEntry(c, cp));
        rv.setOnClickPendingIntent(R.id.carplay, launchIntent(c, cp, 10));

        // siatka = lista aplikacji
        PendingIntent grid;
        if ("system".equals(Prefs.gridMode(c))) {
            Intent all = new Intent(Intent.ACTION_ALL_APPS);
            if (all.resolveActivity(c.getPackageManager()) == null) {
                all = new Intent(Intent.ACTION_MAIN);
                all.addCategory(Intent.CATEGORY_HOME);
            }
            all.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            grid = PendingIntent.getActivity(c, 30, all, PendingIntent.FLAG_UPDATE_CURRENT);
        } else {
            Intent apps = new Intent(c, AppsActivity.class);
            apps.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            grid = PendingIntent.getActivity(c, 30, apps, PendingIntent.FLAG_UPDATE_CURRENT);
        }
        rv.setOnClickPendingIntent(R.id.grid, grid);

        // klik w zegar/statusy = ustawienia
        Intent cfg = new Intent(c, ConfigActivity.class);
        cfg.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        rv.setOnClickPendingIntent(R.id.header, PendingIntent.getActivity(
                c, 20, cfg, PendingIntent.FLAG_UPDATE_CURRENT));

        // napięcie (opcjonalnie)
        if (Prefs.showVoltage(c)) {
            rv.setViewVisibility(R.id.power_row, View.VISIBLE);
            rv.setTextViewText(R.id.volt, Volt.text(c));
        } else {
            rv.setViewVisibility(R.id.power_row, View.GONE);
        }
        return rv;
    }
}
