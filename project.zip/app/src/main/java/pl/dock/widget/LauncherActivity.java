package pl.dock.widget;

import android.app.Activity;
import android.app.Dialog;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

// Launcher: dock po lewej lub prawej, strony: widżety | ekran główny | aplikacje (jak CarPlay).
public class LauncherActivity extends Activity {

    public static volatile boolean visible = false;

    private static final int HOST_ID = 4217;
    private static final int REQ_BIND = 31;
    private static final int REQ_CONFIG = 32;

    private FrameLayout root;
    private BackgroundView bg;
    private PagerView pager;
    private DockView dock;
    private PageDots dots;
    private WidgetPage stacksPage;
    private WidgetPage homePage;
    private final List<AppsGridPage> appPages = new ArrayList<AppsGridPage>();
    private List<AppsGridPage.Item> items = new ArrayList<AppsGridPage.Item>();

    private AppWidgetManager awm;
    private AppWidgetHost host;
    private int pendingId = -1;
    private String pendingWhere = "s1";

    private boolean night;
    private int homeIdx = 0;
    private int appsStart = 1;
    private String clockText = "--:--";
    private String lastDockSig = "";
    private List<AppEntry> topCache = new ArrayList<AppEntry>();
    private AppEntry cpCache;
    private boolean receiversOn;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable minuteTick = new Runnable() {
        @Override
        public void run() {
            boolean n = Look.night(LauncherActivity.this);
            if (n != night) {
                night = n;
                applyTheme();
            }
            refreshDock();
            scheduleMinute();
        }
    };
    private final Runnable statusTick = new Runnable() {
        @Override
        public void run() {
            StatusCenter.refresh(LauncherActivity.this);
            refreshDock();
            h.postDelayed(this, 20000);
        }
    };

    private BroadcastReceiver statusReceiver;
    private BroadcastReceiver pkgReceiver;

    // ---------------------------------------------------------------- cykl życia
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        night = Look.night(this);
        awm = AppWidgetManager.getInstance(this);
        host = new AppWidgetHost(this, HOST_ID);
        buildUi();
        StatusService.start(this);
        updateClockText();
        loadApps();
    }

    @Override
    protected void onStart() {
        super.onStart();
        visible = true;
        try {
            host.startListening();
        } catch (Throwable ignored) {
        }
        registerReceivers();
        StatusCenter.refresh(this);
        lastDockSig = "";
        refreshDock();
        scheduleMinute();
        h.removeCallbacks(statusTick);
        h.postDelayed(statusTick, 20000);
    }

    @Override
    protected void onStop() {
        super.onStop();
        visible = false;
        try {
            host.stopListening();
        } catch (Throwable ignored) {
        }
        unregisterReceivers();
        h.removeCallbacks(minuteTick);
        h.removeCallbacks(statusTick);
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyBars();
        // zmiany ustawień (tapeta, strona dock, widżety) z ekranu ustawień
        if (stacksPageEnabled() != (stacksPage != null) || dockSideChanged()) {
            rebuildAll();
        } else {
            bg.setStyle(Prefs.wallpaper(this), night);
            pager.setReduceMotion(Prefs.reduceMotion(this));
            lastDockSig = "";
            refreshDock();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyBars();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // przycisk Home: wróć na ekran główny
        if (pager != null) pager.goTo(homeIdx, true);
    }

    @Override
    public void onBackPressed() {
        if (pager != null && pager.position() > homeIdx + 0.5f) {
            pager.goTo(homeIdx, true);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        boolean n = Look.night(this);
        if (n != night) {
            night = n;
            applyTheme();
        }
    }

    private boolean stacksPageEnabled() {
        return Prefs.widgetsPage(this);
    }

    private boolean builtLeft = true;

    private boolean dockSideChanged() {
        return builtLeft != Ui.dockLeft(this);
    }

    private void applyBars() {
        if (!Prefs.hideBars(this)) return;
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ---------------------------------------------------------------- budowa interfejsu
    private void buildUi() {
        builtLeft = Ui.dockLeft(this);
        boolean left = builtLeft;
        int dockPx = Ui.dp(this, Ui.DOCK_OFFSET_DP);
        root = new FrameLayout(this);

        bg = new BackgroundView(this);
        root.addView(bg, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        pager = new PagerView(this);
        pager.setReduceMotion(Prefs.reduceMotion(this));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        if (left) {
            plp.leftMargin = dockPx;
        } else {
            plp.rightMargin = dockPx;
        }
        root.addView(pager, plp);

        dots = new PageDots(this);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 24), Gravity.BOTTOM);
        if (left) {
            dlp.leftMargin = dockPx;
        } else {
            dlp.rightMargin = dockPx;
        }
        dlp.bottomMargin = Ui.dp(this, 8);
        root.addView(dots, dlp);

        dock = new DockView(this);
        root.addView(dock, new FrameLayout.LayoutParams(dockPx,
                ViewGroup.LayoutParams.MATCH_PARENT, left ? Gravity.START : Gravity.END));
        dock.setListener(new DockView.Listener() {
            @Override
            public void onHeader() {
                startActivity(new Intent(LauncherActivity.this, ConnectivityActivity.class));
            }

            @Override
            public void onApp(int index) {
                if (index < 3) {
                    if (index < topCache.size()) launch(topCache.get(index));
                } else if (cpCache != null) {
                    launch(cpCache);
                }
            }

            @Override
            public void onBottom() {
                if (pager.position() < homeIdx + 0.5f) {
                    pager.goTo(appsStart, true);
                } else {
                    pager.goTo(homeIdx, true);
                }
            }
        });

        pager.setListener(new PagerView.Listener() {
            @Override
            public void onScroll(float pos) {
                int total = Math.max(1, pager.count() - 1);
                bg.setParallax(Prefs.parallax(LauncherActivity.this) ? pos / total : 0f);
                float t = Math.max(0f, Math.min(1f, pos - homeIdx));
                dock.setBottomProgress(t);
                dots.setAlpha(t);
                dots.set(appPages.size(), pos - appsStart);
            }

            @Override
            public void onSettled(int index) {
            }
        });

        setContentView(root);
        bg.setStyle(Prefs.wallpaper(this), night);
        dots.setLight(!night);
        buildWidgetPages();
        assemblePages();
        lastDockSig = "";
    }

    private void rebuildAll() {
        Bundle keep = null;
        for (int i = 0; i < pager.getChildCount(); i++) {
            // widoki stron są zbudowane od nowa; widżety systemowe tworzymy ponownie
        }
        buildUi();
        refreshDock();
    }

    private void buildWidgetPages() {
        stacksPage = null;
        if (Prefs.widgetsPage(this)) {
            stacksPage = new WidgetPage(this, new String[]{"s1", "s2", "s3"}, true);
            stacksPage.setNight(night);
            stacksPage.setCallbacks(new WidgetPage.Callbacks() {
                @Override
                public void onAdd(String where) {
                    showWidgetPicker(where);
                }

                @Override
                public void onMenu(WidgetEntry e) {
                    widgetMenu(e);
                }

                @Override
                public void onEmptyLong() {
                    showWidgetPicker("s2");
                }
            });
        }
        homePage = new WidgetPage(this, new String[]{"h1", "h2"}, false);
        homePage.setNight(night);
        homePage.setCallbacks(new WidgetPage.Callbacks() {
            @Override
            public void onAdd(String where) {
                showWidgetPicker(where);
            }

            @Override
            public void onMenu(WidgetEntry e) {
                widgetMenu(e);
            }

            @Override
            public void onEmptyLong() {
                Popups.menu(LauncherActivity.this, "Ekran główny",
                        new String[]{"Dodaj widżet", "Ustawienia Docka"}, new Popups.OnSel() {
                            @Override
                            public void on(int i) {
                                if (i == 0) {
                                    showWidgetPicker(homePage.count("h1") <= homePage.count("h2")
                                            ? "h1" : "h2");
                                } else {
                                    openSettings();
                                }
                            }
                        });
            }
        });
        loadWidgets();
    }

    // zbiera strony do pagera: [widżety] [ekran główny] [aplikacje...]
    private void assemblePages() {
        pager.removeAllViews();
        homeIdx = 0;
        if (stacksPage != null) {
            pager.addView(stacksPage, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            homeIdx = 1;
        }
        pager.addView(homePage, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        appsStart = homeIdx + 1;
        for (AppsGridPage p : appPages) {
            if (p.getParent() instanceof ViewGroup) ((ViewGroup) p.getParent()).removeView(p);
            pager.addView(p, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
        pager.setPosition(homeIdx);
    }

    private void applyTheme() {
        bg.setStyle(Prefs.wallpaper(this), night);
        dots.setLight(!night);
        if (stacksPage != null) stacksPage.setNight(night);
        homePage.setNight(night);
        for (AppsGridPage p : appPages) p.setItems(items.size() == 0 ? items : sliceOf(p), night);
        lastDockSig = "";
        refreshDock();
    }

    private List<AppsGridPage.Item> sliceOf(AppsGridPage p) {
        int i = appPages.indexOf(p);
        int from = i * AppsGridPage.PER_PAGE;
        int to = Math.min(items.size(), from + AppsGridPage.PER_PAGE);
        return from >= to ? new ArrayList<AppsGridPage.Item>() : items.subList(from, to);
    }

    // ---------------------------------------------------------------- dock
    private void updateClockText() {
        java.util.Calendar c = java.util.Calendar.getInstance();
        clockText = String.format(Locale.US, "%02d:%02d", c.get(java.util.Calendar.HOUR_OF_DAY),
                c.get(java.util.Calendar.MINUTE));
    }

    private void scheduleMinute() {
        h.removeCallbacks(minuteTick);
        long now = System.currentTimeMillis();
        h.postDelayed(minuteTick, 60000L - (now % 60000L) + 30L);
    }

    // odświeża dock tylko wtedy, gdy zmieniły się dane
    private void refreshDock() {
        updateClockText();
        StatusCenter.Snap s = StatusCenter.get(this);
        String sig = Prefs.version + "|" + Icons.version() + "|" + s.sig() + "|" + night + "|"
                + clockText;
        if (sig.equals(lastDockSig)) return;
        lastDockSig = sig;
        topCache = Prefs.top(this, 3);
        cpCache = Prefs.carplay(this);
        Bitmap[] ic = new Bitmap[4];
        for (int i = 0; i < 3 && i < topCache.size(); i++) {
            ic[i] = Icons.forEntry(this, topCache.get(i));
        }
        ic[3] = Icons.forEntry(this, cpCache);
        dock.setData(night, "glass".equals(Prefs.style(this)), clockText, s,
                Prefs.showVoltage(this), ic);
    }

    // ---------------------------------------------------------------- odbiorniki (tylko gdy widoczny)
    private void registerReceivers() {
        if (receiversOn) return;
        receiversOn = true;
        statusReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())
                        && !Prefs.showVoltage(context)) {
                    return;
                }
                StatusCenter.refresh(context);
                refreshDock();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        f.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
        f.addAction("android.net.conn.TETHER_STATE_CHANGED");
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction("android.hardware.usb.action.USB_DEVICE_ATTACHED");
        f.addAction("android.hardware.usb.action.USB_DEVICE_DETACHED");
        registerReceiver(statusReceiver, f);

        pkgReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Icons.invalidate();
                loadApps();
            }
        };
        IntentFilter p = new IntentFilter();
        p.addAction(Intent.ACTION_PACKAGE_ADDED);
        p.addAction(Intent.ACTION_PACKAGE_REMOVED);
        p.addAction(Intent.ACTION_PACKAGE_REPLACED);
        p.addDataScheme("package");
        registerReceiver(pkgReceiver, p);
    }

    private void unregisterReceivers() {
        if (!receiversOn) return;
        receiversOn = false;
        try {
            unregisterReceiver(statusReceiver);
            unregisterReceiver(pkgReceiver);
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- aplikacje
    private void loadApps() {
        final Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<AppsGridPage.Item> list = buildItems(app);
                // rozgrzewamy pamięć podręczną ikon poza głównym wątkiem
                for (AppsGridPage.Item it : list) {
                    if (it.settings) {
                        Icons.builtin(app, "settings");
                    } else if (it.entry != null) {
                        Icons.forEntry(app, it.entry);
                    } else {
                        Icons.forPackage(app, it.pkg);
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) return;
                        items = list;
                        rebuildAppPages();
                    }
                });
            }
        }).start();
    }

    private List<AppsGridPage.Item> buildItems(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(main, 0);
        final List<AppsGridPage.Item> others = new ArrayList<AppsGridPage.Item>();
        List<AppsGridPage.Item> chosen = new ArrayList<AppsGridPage.Item>();
        Set<String> chosenPk = new HashSet<String>();
        List<AppEntry> entries = Prefs.apps(c);
        for (AppEntry e : entries) {
            if (e.pkg.length() == 0 || pm.getLaunchIntentForPackage(e.pkg) == null) continue;
            AppsGridPage.Item it = new AppsGridPage.Item();
            it.entry = e;
            it.pkg = e.pkg;
            try {
                it.label = pm.getApplicationLabel(pm.getApplicationInfo(e.pkg, 0)).toString();
            } catch (Throwable t) {
                it.label = e.pkg;
            }
            chosen.add(it);
            chosenPk.add(e.pkg);
        }
        if (!Prefs.gridOnlySelected(c)) {
            Set<String> seen = new HashSet<String>();
            for (ResolveInfo ri : ris) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(c.getPackageName()) || chosenPk.contains(pkg) || !seen.add(pkg)) {
                    continue;
                }
                AppsGridPage.Item it = new AppsGridPage.Item();
                it.pkg = pkg;
                it.label = ri.loadLabel(pm).toString();
                others.add(it);
            }
            Collections.sort(others, new Comparator<AppsGridPage.Item>() {
                @Override
                public int compare(AppsGridPage.Item a, AppsGridPage.Item b) {
                    return a.label.compareToIgnoreCase(b.label);
                }
            });
        }
        List<AppsGridPage.Item> out = new ArrayList<AppsGridPage.Item>();
        AppsGridPage.Item st = new AppsGridPage.Item();
        st.settings = true;
        st.label = "Ustawienia";
        out.add(st);
        out.addAll(chosen);
        out.addAll(others);
        return out;
    }

    private void rebuildAppPages() {
        appPages.clear();
        int n = Math.max(1, (items.size() + AppsGridPage.PER_PAGE - 1) / AppsGridPage.PER_PAGE);
        for (int i = 0; i < n; i++) {
            AppsGridPage p = new AppsGridPage(this);
            int from = i * AppsGridPage.PER_PAGE;
            int to = Math.min(items.size(), from + AppsGridPage.PER_PAGE);
            p.setItems(new ArrayList<AppsGridPage.Item>(items.subList(from, to)), night);
            p.setListener(new AppsGridPage.Listener() {
                @Override
                public void onTap(AppsGridPage.Item it) {
                    if (it.settings) {
                        openSettings();
                    } else if (it.entry != null) {
                        launch(it.entry);
                    } else {
                        launchPkg(it.pkg);
                    }
                }

                @Override
                public void onLong(AppsGridPage.Item it) {
                    appMenu(it);
                }
            });
            appPages.add(p);
        }
        float pos = pager.position();
        assemblePages();
        pager.setPosition(Math.min(pos, pager.count() - 1));
    }

    private void appMenu(final AppsGridPage.Item it) {
        if (it.settings) return;
        final boolean inList = it.entry != null;
        Popups.menu(this, it.label, new String[]{
                inList ? "Usuń z listy Docka" : "Dodaj do listy Docka",
                "Informacje o aplikacji"}, new Popups.OnSel() {
            @Override
            public void on(int i) {
                if (i == 0) {
                    if (inList) {
                        Prefs.remove(LauncherActivity.this, it.entry.id);
                    } else {
                        Prefs.add(LauncherActivity.this, it.pkg);
                    }
                    lastDockSig = "";
                    refreshDock();
                    loadApps();
                } else {
                    try {
                        Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + it.pkg));
                        startActivity(d);
                    } catch (Throwable ignored) {
                    }
                }
            }
        });
    }

    private void launch(AppEntry e) {
        if (e.id != 0) Prefs.recordUse(this, e.id);
        launchPkg(e.pkg);
        lastDockSig = "";
        refreshDock();
    }

    private void launchPkg(String pkg) {
        try {
            Intent i = pkg == null || pkg.length() == 0 ? null
                    : getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) {
                Toast.makeText(this, "Nie wybrano aplikacji – ustaw ją w ustawieniach Docka",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(this, "Nie udało się uruchomić aplikacji", Toast.LENGTH_SHORT).show();
        }
    }

    private void openSettings() {
        startActivity(new Intent(this, ConfigActivity.class));
    }

    // ---------------------------------------------------------------- widżety
    private void loadWidgets() {
        if (stacksPage != null) stacksPage.clearWidgets();
        homePage.clearWidgets();
        List<WidgetEntry> list = Prefs.widgets(this);
        if (!Prefs.widgetsSeeded(this)) {
            // domyślnie jak w CarPlay: zegar w 1. kolumnie, odtwarzanie w 3.
            WidgetEntry c = new WidgetEntry();
            c.id = -1;
            c.where = "s1";
            WidgetEntry m = new WidgetEntry();
            m.id = -2;
            m.where = "s3";
            list.add(c);
            list.add(m);
            Prefs.saveWidgets(this, list);
            Prefs.setWidgetsSeeded(this);
        }
        boolean changed = false;
        List<WidgetEntry> keep = new ArrayList<WidgetEntry>();
        for (WidgetEntry e : list) {
            View v = createWidgetView(e);
            WidgetPage page = pageFor(e.where);
            if (v == null || page == null) {
                changed = true;
                continue;
            }
            page.addWidget(e, v);
            keep.add(e);
        }
        if (changed) Prefs.saveWidgets(this, keep);
        if (stacksPage != null) stacksPage.applySelection();
        homePage.applySelection();
    }

    private WidgetPage pageFor(String where) {
        if (where.startsWith("s")) return stacksPage;
        return homePage;
    }

    private View createWidgetView(WidgetEntry e) {
        try {
            if (e.id == -1) {
                ClockCard cc = new ClockCard(this);
                cc.setNight(night);
                return cc;
            }
            if (e.id == -2) {
                NowPlayingCard n = new NowPlayingCard(this);
                n.setNight(night);
                return n;
            }
            AppWidgetProviderInfo info = awm.getAppWidgetInfo(e.id);
            if (info == null) return null;
            AppWidgetHostView hv = host.createView(this, e.id, info);
            return hv;
        } catch (Throwable t) {
            return null;
        }
    }

    private void showWidgetPicker(final String where) {
        if (where.startsWith("s") && stacksPage == null) return;
        PackageManager pm = getPackageManager();
        final List<String> labels = new ArrayList<String>();
        final List<AppWidgetProviderInfo> infos = new ArrayList<AppWidgetProviderInfo>();
        labels.add("Zegar analogowy");
        labels.add("Odtwarzane (DiPlay)");
        List<AppWidgetProviderInfo> all = awm.getInstalledProviders();
        final List<AppWidgetProviderInfo> sorted = new ArrayList<AppWidgetProviderInfo>(all);
        final PackageManager pmf = pm;
        Collections.sort(sorted, new Comparator<AppWidgetProviderInfo>() {
            @Override
            public int compare(AppWidgetProviderInfo a, AppWidgetProviderInfo b) {
                return a.loadLabel(pmf).compareToIgnoreCase(b.loadLabel(pmf));
            }
        });
        for (AppWidgetProviderInfo i : sorted) {
            labels.add(i.loadLabel(pm) + "  ·  " + i.provider.getPackageName());
            infos.add(i);
        }
        Popups.menu(this, "Dodaj widżet", labels.toArray(new String[0]), new Popups.OnSel() {
            @Override
            public void on(int idx) {
                if (idx == 0) {
                    addBuiltin(-1, where);
                } else if (idx == 1) {
                    addBuiltin(-2, where);
                } else {
                    beginBind(infos.get(idx - 2), where);
                }
            }
        });
    }

    private void addBuiltin(int id, String where) {
        List<WidgetEntry> list = Prefs.widgets(this);
        for (WidgetEntry e : list) {
            if (e.id == id) {
                Toast.makeText(this, "Ten widżet jest już dodany", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        WidgetEntry e = new WidgetEntry();
        e.id = id;
        e.where = where;
        list.add(e);
        Prefs.saveWidgets(this, list);
        attach(e);
    }

    private void attach(WidgetEntry e) {
        View v = createWidgetView(e);
        WidgetPage page = pageFor(e.where);
        if (v == null || page == null) return;
        page.addWidget(e, v);
        page.applySelection();
    }

    private void beginBind(AppWidgetProviderInfo info, String where) {
        pendingWhere = where;
        pendingId = host.allocateAppWidgetId();
        boolean ok = false;
        try {
            ok = awm.bindAppWidgetIdIfAllowed(pendingId, info.provider);
        } catch (Throwable ignored) {
        }
        if (ok) {
            afterBind();
        } else {
            try {
                Intent i = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
                i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId);
                i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider);
                startActivityForResult(i, REQ_BIND);
            } catch (Throwable t) {
                Toast.makeText(this, "System nie pozwala dodać tego widżetu", Toast.LENGTH_LONG).show();
                cancelPending();
            }
        }
    }

    private void afterBind() {
        AppWidgetProviderInfo info = awm.getAppWidgetInfo(pendingId);
        if (info != null && info.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, pendingId, 0, REQ_CONFIG, null);
                return;
            } catch (Throwable t) {
                // brak konfiguracji = spróbuj dodać bez niej
            }
        }
        finishAdd();
    }

    private void finishAdd() {
        WidgetEntry e = new WidgetEntry();
        e.id = pendingId;
        e.where = pendingWhere;
        List<WidgetEntry> list = Prefs.widgets(this);
        list.add(e);
        Prefs.saveWidgets(this, list);
        attach(e);
        pendingId = -1;
    }

    private void cancelPending() {
        if (pendingId >= 0) {
            try {
                host.deleteAppWidgetId(pendingId);
            } catch (Throwable ignored) {
            }
        }
        pendingId = -1;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_BIND) {
            if (res == RESULT_OK && pendingId >= 0) {
                afterBind();
            } else {
                cancelPending();
            }
        } else if (req == REQ_CONFIG) {
            if (res == RESULT_OK && pendingId >= 0) {
                finishAdd();
            } else {
                cancelPending();
            }
        }
    }

    private void widgetMenu(final WidgetEntry e) {
        final WidgetPage page = pageFor(e.where);
        final List<String> items2 = new ArrayList<String>();
        final boolean multi = page != null && page.count(e.where) > 1;
        if (multi) items2.add("Następny widżet w kolumnie");
        items2.add("Usuń widżet");
        Popups.menu(this, "Widżet", items2.toArray(new String[0]), new Popups.OnSel() {
            @Override
            public void on(int i) {
                if (multi && i == 0) {
                    if (page != null) page.cycle(e.where);
                } else {
                    Popups.confirm(LauncherActivity.this, "Usunąć widżet?", "", "Usuń", new Runnable() {
                        @Override
                        public void run() {
                            removeWidget(e);
                        }
                    });
                }
            }
        });
    }

    private void removeWidget(WidgetEntry e) {
        if (e.id > 0) {
            try {
                host.deleteAppWidgetId(e.id);
            } catch (Throwable ignored) {
            }
        }
        List<WidgetEntry> list = Prefs.widgets(this);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == e.id) {
                list.remove(i);
                break;
            }
        }
        Prefs.saveWidgets(this, list);
        WidgetPage page = pageFor(e.where);
        if (page != null) page.removeWidget(e.id);
    }
}
