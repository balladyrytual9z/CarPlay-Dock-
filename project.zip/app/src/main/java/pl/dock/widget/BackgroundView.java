package pl.dock.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

// Tło launchera w stylu CarPlay. Rysowane raz do małej bitmapy (pół rozdzielczości),
// potem tylko przesuwane (paralaksa) podczas przewijania stron.
public class BackgroundView extends View {

    private Bitmap bmp;
    private String style = "navy";
    private boolean night = true;
    private float parallax;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF dst = new RectF();

    public BackgroundView(Context c) {
        super(c);
    }

    public void setStyle(String style, boolean night) {
        if (style.equals(this.style) && night == this.night && bmp != null) return;
        this.style = style;
        this.night = night;
        rebuild();
        invalidate();
    }

    // 0..1: pozycja przewijania
    public void setParallax(float p) {
        if (Math.abs(p - parallax) < 0.003f) return;
        parallax = p;
        if (bmp != null) invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rebuild();
    }

    private void rebuild() {
        if (bmp != null) {
            bmp.recycle();
            bmp = null;
        }
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0 || "system".equals(style)) return;
        int bw = Math.max(64, w / 2);
        int bh = Math.max(64, h / 2);
        bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        paintStyle(new Canvas(bmp), bw, bh);
    }

    private void paintStyle(Canvas cv, int bw, int bh) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        boolean navy = !"graphite".equals(style);
        if (night) {
            if (navy) {
                cv.drawColor(0xFF070A16);
                p.setShader(new RadialGradient(bw * 0.28f, -bh * 0.20f, bh * 1.25f,
                        new int[]{0xFF14513F, 0xFF0B2B27, 0x000B2B27},
                        new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, bw, bh, p);
                p.setShader(new RadialGradient(bw * 0.90f, bh * 1.02f, bh * 0.85f,
                        new int[]{0xFF2B3566, 0xFF171E45, 0x00171E45},
                        new float[]{0f, 0.65f, 1f}, Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, bw, bh, p);
            } else {
                cv.drawColor(0xFF1B1B1D);
                p.setShader(new RadialGradient(bw * 0.82f, bh * 0.95f, bh * 1.05f,
                        new int[]{0xFF3A3A3C, 0xFF262628, 0x00262628},
                        new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, bw, bh, p);
                p.setShader(new RadialGradient(bw * 0.08f, bh * 0.05f, bh * 0.95f,
                        new int[]{0xFF303033, 0x00303033}, null, Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, bw, bh, p);
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(1.2f);
                p.setColor(0x22FFFFFF);
                cv.drawCircle(bw * 0.95f, bh * 1.35f, bh * 0.98f, p);
                cv.drawCircle(bw * 0.02f, bh * 0.60f, bh * 0.72f, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, bh * 0.78f, 0, bh, 0x00000000, 0x66000000,
                    Shader.TileMode.CLAMP));
            cv.drawRect(0, bh * 0.78f, bw, bh, p);
        } else {
            if (navy) {
                cv.drawColor(0xFFDCE4F0);
                p.setShader(new RadialGradient(bw * 0.28f, -bh * 0.20f, bh * 1.25f,
                        new int[]{0xFFBFE3D8, 0xFFCFE7E4, 0x00CFE7E4},
                        new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, bw, bh, p);
                p.setShader(new RadialGradient(bw * 0.90f, bh * 1.02f, bh * 0.85f,
                        new int[]{0xFFB4BFE8, 0xFFC9D1EE, 0x00C9D1EE},
                        new float[]{0f, 0.65f, 1f}, Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, bw, bh, p);
            } else {
                cv.drawColor(0xFFE8E8ED);
                p.setShader(new RadialGradient(bw * 0.82f, bh * 0.95f, bh * 1.05f,
                        new int[]{0xFFF8F8FB, 0xFFEDEDF2, 0x00EDEDF2},
                        new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
                cv.drawRect(0, 0, bw, bh, p);
            }
        }
    }

    @Override
    protected void onDraw(Canvas cv) {
        if (bmp == null) return;
        float extra = getWidth() * 0.06f;
        dst.set(-extra * parallax, 0, getWidth() + extra * (1f - parallax), getHeight());
        cv.drawBitmap(bmp, null, dst, paint);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (bmp != null) {
            bmp.recycle();
            bmp = null;
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (bmp == null && getWidth() > 0) rebuild();
    }
}
