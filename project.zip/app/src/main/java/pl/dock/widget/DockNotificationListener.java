package pl.dock.widget;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

// Daje dostęp do sesji multimedialnych innych aplikacji (np. DiPlay) i ich powiadomień.
// Wymaga jednorazowego włączenia "Dostępu do powiadomień" dla Docka w ustawieniach Androida.
public class DockNotificationListener extends NotificationListenerService {

    private static volatile DockNotificationListener instance;

    public static boolean connected() {
        return instance != null;
    }

    public static boolean hasNotificationFrom(String pkg) {
        DockNotificationListener l = instance;
        if (l == null || pkg == null) return false;
        try {
            StatusBarNotification[] all = l.getActiveNotifications();
            if (all == null) return false;
            for (StatusBarNotification n : all) {
                if (pkg.equals(n.getPackageName())) return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    // tytuł i tekst pierwszego powiadomienia aplikacji (do diagnostyki i zastępczych danych odtwarzania)
    public static String[] notificationText(String pkg) {
        DockNotificationListener l = instance;
        if (l == null || pkg == null) return null;
        try {
            StatusBarNotification[] all = l.getActiveNotifications();
            if (all == null) return null;
            for (StatusBarNotification n : all) {
                if (!pkg.equals(n.getPackageName())) continue;
                android.os.Bundle ex = n.getNotification().extras;
                if (ex == null) continue;
                CharSequence t = ex.getCharSequence(Notification.EXTRA_TITLE);
                CharSequence x = ex.getCharSequence(Notification.EXTRA_TEXT);
                return new String[]{t == null ? "" : t.toString(), x == null ? "" : x.toString()};
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    @Override
    public void onListenerConnected() {
        instance = this;
        MediaHub.get().onListenerEvent();
        notifyStatus();
    }

    @Override
    public void onListenerDisconnected() {
        instance = null;
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        MediaHub.get().onListenerEvent();
        notifyStatus();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        MediaHub.get().onListenerEvent();
        notifyStatus();
    }

    private void notifyStatus() {
        try {
            StatusCenter.refresh(this);
            DockWidget.updateAll(this);
        } catch (Throwable ignored) {
        }
    }
}
