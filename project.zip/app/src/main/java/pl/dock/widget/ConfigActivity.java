package pl.dock.widget;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Ustawienia w stylu CarPlay: ciemne tło, duże wiersze, segmenty, lista aplikacji.
 */
public class ConfigActivity extends Activity {

    private static final int REQ_FILE = 1;
    private int fileIndex = -1;
    private String filePkg = null;

    private static final int BG = 0xFF0B0B0F;
    private static final int CARD = 0xFF1C1C22;
    private static final int CARD_ALT = 0xFF25252E;
    private static final int ACCENT = 0xFF3A7BD5;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int TEXT_DIM = 0xFFAAAAAA;
    private static final int DIVIDER = 0x33FFFFFF;

    private static class AppItem {
        String label;
        String pkg;
    }

    private interface OnPick {
        void on(String pkg);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        StatusService.start(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        build();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable cardBg(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp((int) radiusDp));
        return g;
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(40));
        sv.addView(root);

        // Tytuł w stylu CarPlay
        TextView title = new TextView(this);
        title.setText("Dock");
        title.setTextSize(32);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        title.setTextColor(TEXT);
        title.setPadding(0, 0, 0, dp(4));
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Ustawienia");
        sub.setTextSize(15);
        sub.setTextColor(TEXT_DIM);
        sub.setPadding(0, 0, 0, dp(20));
        root.addView(sub);

        // --- WYGLĄD ---
        root.addView(sectionHeader("WYGLĄD"));

        LinearLayout styleCard = sectionCard();
        styleCard.addView(segmentRow("Styl",
                new String[]{"Klasyczny", "Liquid Glass"},
                new String[]{"classic", "liquid_glass"},
                Prefs.themeStyle(this),
                new OnPick() {
                    @Override
                    public void on(String v) {
                        Prefs.setThemeStyle(ConfigActivity.this, v);
                        DockWidget.updateAll(ConfigActivity.this);
                        build();
                    }
                }));
        styleCard.addView(divider());
        styleCard.addView(segmentRow("Tryb",
                new String[]{"Dzień", "Noc", "System"},
                new String[]{"day", "night", "system"},
                Prefs.themeMode(this),
                new OnPick() {
                    @Override
                    public void on(String v) {
                        Prefs.setThemeMode(ConfigActivity.this, v);
                        DockWidget.updateAll(ConfigActivity.this);
                        build();
                    }
                }));
        root.addView(styleCard);

        // --- DOCK ---
        root.addView(sectionHeader("DOCK"));

        LinearLayout dockCard = sectionCard();
        dockCard.addView(segmentRow("Kolejność ikon",
                new String[]{"Ostatnie", "Najczęstsze"},
                new String[]{"recent", "frequent"},
                Prefs.rankingMode(this),
                new OnPick() {
                    @Override
                    public void on(String v) {
                        Prefs.setRankingMode(ConfigActivity.this, v);
                        DockWidget.updateAll(ConfigActivity.this);
                        build();
                    }
                }));
        dockCard.addView(divider());
        dockCard.addView(toggleRow("Pokaż napięcie", Prefs.showVoltage(this), new OnPick() {
            @Override
            public void on(String v) {
                Prefs.setShowVoltage(ConfigActivity.this, "1".equals(v));
                DockWidget.updateAll(ConfigActivity.this);
            }
        }));
        root.addView(dockCard);

        // --- CARPLAY (przypięty na dole) ---
        root.addView(sectionHeader("CARPLAY (zawsze na dole)"));
        LinearLayout pinCard = sectionCard();
        pinCard.addView(pinnedRow());
        root.addView(pinCard);

        // --- APLIKACJE ---
        root.addView(sectionHeader("APLIKACJE W DOCKU"));
        TextView hint = new TextView(this);
        hint.setText("Na widżecie widać 3 z listy (wg kolejności użycia) + CarPlay. Dodaj dowolną liczbę.");
        hint.setTextSize(13);
        hint.setTextColor(TEXT_DIM);
        hint.setPadding(dp(4), 0, dp(4), dp(10));
        root.addView(hint);

        LinearLayout appsCard = sectionCard();
        List<Prefs.AppEntry> apps = Prefs.getApps(this);
        for (int i = 0; i < apps.size(); i++) {
            if (i > 0) appsCard.addView(divider());
            appsCard.addView(appRow(i, apps.get(i)));
        }
        appsCard.addView(divider());
        appsCard.addView(addAppButton());
        root.addView(appsCard);

        setContentView(sv);
    }

    private TextView sectionHeader(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(TEXT_DIM);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(8), dp(18), 0, dp(8));
        t.setLetterSpacing(0.05f);
        return t;
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(cardBg(CARD, 16));
        card.setPadding(0, dp(4), 0, dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(4);
        card.setLayoutParams(lp);
        return card;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lp.setMargins(dp(16), 0, dp(16), 0);
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout segmentRow(String label, final String[] labels, final String[] values,
                                    String current, final OnPick cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(12), dp(16), dp(12));

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextSize(16);
        lbl.setTextColor(TEXT);
        row.addView(lbl);

        LinearLayout segs = new LinearLayout(this);
        segs.setOrientation(LinearLayout.HORIZONTAL);
        segs.setPadding(0, dp(10), 0, 0);

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView seg = new TextView(this);
            seg.setText(labels[i]);
            seg.setTextSize(14);
            seg.setGravity(Gravity.CENTER);
            seg.setPadding(dp(12), dp(10), dp(12), dp(10));
            boolean selected = values[i].equals(current);
            GradientDrawable bg = cardBg(selected ? ACCENT : CARD_ALT, 10);
            seg.setBackground(bg);
            seg.setTextColor(TEXT);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = dp(8);
            seg.setLayoutParams(lp);
            seg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cb.on(values[idx]);
                }
            });
            segs.addView(seg);
        }
        row.addView(segs);
        return row;
    }

    private LinearLayout toggleRow(String label, boolean on, final OnPick cb) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextSize(16);
        lbl.setTextColor(TEXT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lbl.setLayoutParams(lp);
        row.addView(lbl);

        final TextView toggle = new TextView(this);
        toggle.setText(on ? "WŁ" : "WYŁ");
        toggle.setTextSize(14);
        toggle.setTypeface(Typeface.DEFAULT_BOLD);
        toggle.setGravity(Gravity.CENTER);
        toggle.setPadding(dp(16), dp(8), dp(16), dp(8));
        toggle.setBackground(cardBg(on ? ACCENT : CARD_ALT, 10));
        toggle.setTextColor(TEXT);
        final boolean[] state = {on};
        toggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                state[0] = !state[0];
                toggle.setText(state[0] ? "WŁ" : "WYŁ");
                toggle.setBackground(cardBg(state[0] ? ACCENT : CARD_ALT, 10));
                cb.on(state[0] ? "1" : "0");
            }
        });
        row.addView(toggle);
        return row;
    }

    private LinearLayout pinnedRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(12), dp(16), dp(12));

        final String pkg = Prefs.pinnedPkg(this);
        ImageView iv = new ImageView(this);
        Prefs.AppEntry pe = Prefs.entryFor(this, pkg);
        iv.setImageBitmap(Icons.forEntry(this, pe));
        row.addView(iv, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), 0, 0, 0);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        col.setLayoutParams(clp);

        TextView name = new TextView(this);
        name.setText(appLabel(pkg));
        name.setTextSize(17);
        name.setTextColor(TEXT);
        col.addView(name);

        TextView hint = new TextView(this);
        hint.setText("Dotknij, aby zmienić");
        hint.setTextSize(13);
        hint.setTextColor(TEXT_DIM);
        col.addView(hint);
        row.addView(col);

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickApp(new OnPick() {
                    @Override
                    public void on(String p) {
                        Prefs.setPinnedPkg(ConfigActivity.this, p);
                        Prefs.addApp(ConfigActivity.this, p);
                        DockWidget.updateAll(ConfigActivity.this);
                        build();
                    }
                });
            }
        });
        return row;
    }

    private LinearLayout appRow(final int index, final Prefs.AppEntry entry) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(12), dp(10));

        ImageView iv = new ImageView(this);
        iv.setImageBitmap(Icons.forEntry(this, entry));
        row.addView(iv, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), 0, 0, 0);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        col.setLayoutParams(clp);

        TextView name = new TextView(this);
        name.setText(appLabel(entry.pkg));
        name.setTextSize(16);
        name.setTextColor(TEXT);
        col.addView(name);

        String modeLabel = "default".equals(entry.iconMode) ? "Ikona aplikacji"
                : "file".equals(entry.iconMode) ? "Własny obraz"
                : "Ikona innej app";
        TextView meta = new TextView(this);
        meta.setText(modeLabel + "  ·  " + Prefs.useCount(this, entry.pkg) + "×");
        meta.setTextSize(12);
        meta.setTextColor(TEXT_DIM);
        col.addView(meta);
        row.addView(col);

        // przyciski akcji
        TextView btnIcon = actionChip("Ikona");
        btnIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconMenu(index, entry.pkg);
            }
        });
        row.addView(btnIcon);

        TextView btnDel = actionChip("Usuń");
        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.removeApp(ConfigActivity.this, index);
                DockWidget.updateAll(ConfigActivity.this);
                build();
            }
        });
        row.addView(btnDel);

        return row;
    }

    private TextView actionChip(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(TEXT);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        t.setBackground(cardBg(CARD_ALT, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    private LinearLayout addAppButton() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView t = new TextView(this);
        t.setText("+  Dodaj aplikację");
        t.setTextSize(16);
        t.setTextColor(ACCENT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(t);

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickApp(new OnPick() {
                    @Override
                    public void on(String pkg) {
                        Prefs.addApp(ConfigActivity.this, pkg);
                        DockWidget.updateAll(ConfigActivity.this);
                        build();
                    }
                });
            }
        });
        return row;
    }

    private void iconMenu(final int index, final String pkg) {
        String[] items = {"Z pliku (obraz)", "Ikona innej aplikacji", "Domyślna ikona aplikacji"};
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle("Ikona")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                            i.setType("image/*");
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            if (i.resolveActivity(getPackageManager()) == null) {
                                Toast.makeText(ConfigActivity.this,
                                        "Brak wyboru plików – użyj ikony innej aplikacji",
                                        Toast.LENGTH_LONG).show();
                                return;
                            }
                            fileIndex = index;
                            filePkg = pkg;
                            startActivityForResult(i, REQ_FILE);
                        } else if (which == 1) {
                            pickApp(new OnPick() {
                                @Override
                                public void on(String p) {
                                    Prefs.updateAppIcon(ConfigActivity.this, index, "app", p);
                                    DockWidget.updateAll(ConfigActivity.this);
                                    build();
                                }
                            });
                        } else {
                            Prefs.updateAppIcon(ConfigActivity.this, index, "default", "");
                            DockWidget.updateAll(ConfigActivity.this);
                            build();
                        }
                    }
                }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && res == RESULT_OK && data != null && data.getData() != null
                && fileIndex >= 0 && filePkg != null) {
            try {
                Uri u = data.getData();
                boolean ok = Icons.saveFromStream(this, filePkg,
                        getContentResolver().openInputStream(u),
                        getContentResolver().openInputStream(u));
                if (ok) {
                    Prefs.updateAppIcon(this, fileIndex, "file", "");
                    DockWidget.updateAll(this);
                    build();
                } else {
                    Toast.makeText(this, "Nie udało się wczytać obrazu", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Nie udało się wczytać obrazu", Toast.LENGTH_LONG).show();
            }
        }
        fileIndex = -1;
        filePkg = null;
    }

    private String appLabel(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return pkg + " (brak)";
        }
    }

    private void pickApp(final OnPick cb) {
        final PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(main, 0);
        final List<AppItem> items = new ArrayList<AppItem>();
        for (ResolveInfo ri : ris) {
            AppItem a = new AppItem();
            a.label = ri.loadLabel(pm).toString();
            a.pkg = ri.activityInfo.packageName;
            items.add(a);
        }
        Collections.sort(items, new Comparator<AppItem>() {
            @Override
            public int compare(AppItem x, AppItem y) {
                return x.label.compareToIgnoreCase(y.label);
            }
        });

        ListView lv = new ListView(this);
        lv.setBackgroundColor(CARD);
        final AlertDialog dlg = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
                .setTitle("Wybierz aplikację")
                .setView(lv)
                .setNegativeButton("Anuluj", null)
                .create();

        lv.setAdapter(new ArrayAdapter<AppItem>(this, 0, items) {
            @Override
            public View getView(int pos, View cv, ViewGroup parent) {
                Context c = getContext();
                LinearLayout r = new LinearLayout(c);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(dp(12), dp(10), dp(12), dp(10));
                r.setBackgroundColor(CARD);
                ImageView iv = new ImageView(c);
                AppItem a = getItem(pos);
                iv.setImageBitmap(Icons.forPackage(c, a.pkg));
                r.addView(iv, new LinearLayout.LayoutParams(dp(44), dp(44)));
                TextView t = new TextView(c);
                t.setText(a.label);
                t.setTextSize(17);
                t.setTextColor(TEXT);
                t.setPadding(dp(14), 0, 0, 0);
                r.addView(t);
                return r;
            }
        });
        lv.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                dlg.dismiss();
                cb.on(items.get(pos).pkg);
            }
        });
        dlg.show();
    }
}
