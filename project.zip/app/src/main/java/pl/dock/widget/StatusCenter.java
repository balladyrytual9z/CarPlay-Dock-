package pl.dock.widget;

import android.content.Context;
import android.os.SystemClock;

// Jeden wspólny odczyt stanu WiFi / Bluetooth / tetheringu / napięcia.
// Odczyt jest drogi (refleksja, interfejsy sieciowe), więc robimy go po zdarzeniu,
// a nie przy każdym rysowaniu.
public class StatusCenter {

    public static class Snap {
        public boolean wifiEn, wifiCon, bt, tether;
        public int cp;
        public String volt = "";

        boolean same(Snap o) {
            return o != null && wifiEn == o.wifiEn && wifiCon == o.wifiCon && bt == o.bt
                    && tether == o.tether && cp == o.cp && volt.equals(o.volt);
        }

        public String sig() {
            return (wifiEn ? "1" : "0") + (wifiCon ? "1" : "0") + (bt ? "1" : "0")
                    + (tether ? "1" : "0") + cp + "|" + volt;
        }
    }

    private static Snap last;
    private static long lastAt;

    // zwraca true, jeśli stan się zmienił
    public static synchronized boolean refresh(Context c) {
        Context app = c.getApplicationContext();
        Snap s = new Snap();
        s.wifiEn = Net.wifiEnabled(app);
        s.wifiCon = Net.wifiConnected(app);
        s.bt = Net.bluetoothOn();
        s.tether = Net.tethering(app);
        s.cp = CarplayState.read(app);
        s.volt = Prefs.showVoltage(app) ? Volt.text(app) : "";
        boolean changed = !s.same(last);
        last = s;
        lastAt = SystemClock.elapsedRealtime();
        return changed;
    }

    public static synchronized Snap get(Context c) {
        if (last == null || SystemClock.elapsedRealtime() - lastAt > 5000) refresh(c);
        return last;
    }
}
