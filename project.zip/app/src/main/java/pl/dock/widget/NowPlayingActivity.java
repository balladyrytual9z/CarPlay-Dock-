package pl.dock.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

// Pełnoekranowe "Odtwarzane" (okładka, tytuł, sterowanie, postęp, przyciski dodatkowe).
// Okno zaczyna się obok docka, więc dock zostaje widoczny jak w CarPlay.
public class NowPlayingActivity extends Activity implements MediaHub.Listener {

    private PlayerView pv;
    private FrameLayout root;
    private boolean night;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (pv != null) pv.invalidate();
            if (pv != null && pv.t.playing()) h.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        night = Look.night(this);
        setTheme(android.R.style.Theme_Translucent_NoTitleBar);
        super.onCreate(b);
        Ui.dockWindow(getWindow(), this);
        root = new FrameLayout(this);
        root.setBackground(Ui.pageBg(this, night));
        pv = new PlayerView(this);
        root.addView(pv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    @Override
    protected void onStart() {
        super.onStart();
        MediaHub.get().attach(this, this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        h.removeCallbacks(tick);
        MediaHub.get().detach(this);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
    }

    @Override
    public void onTrack(MediaHub.Track t) {
        pv.t = t;
        h.removeCallbacks(tick);
        if (t.playing()) h.postDelayed(tick, 1000);
        // tło w kolorze okładki
        if (t.art != null) {
            int c = avg(t.art);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{c, night ? 0xFF0F0F14 : 0xFFEDEDF2});
            float r = Ui.dp(this, 26);
            g.setCornerRadii(Ui.dockLeft(this) ? new float[]{r, r, 0, 0, 0, 0, r, r}
                    : new float[]{0, 0, r, r, r, r, 0, 0});
            root.setBackground(g);
        } else {
            root.setBackground(Ui.pageBg(this, night));
        }
        pv.invalidate();
    }

    private static int avg(Bitmap b) {
        try {
            Bitmap s = Bitmap.createScaledBitmap(b, 8, 8, true);
            long r = 0, g = 0, bl = 0;
            for (int y = 0; y < 8; y++) {
                for (int x = 0; x < 8; x++) {
                    int p = s.getPixel(x, y);
                    r += Color.red(p);
                    g += Color.green(p);
                    bl += Color.blue(p);
                }
            }
            return Color.rgb((int) (r / 64 * 0.7), (int) (g / 64 * 0.7), (int) (bl / 64 * 0.7));
        } catch (Throwable t) {
            return 0xFF2A2A30;
        }
    }

    // ------------------------------------------------------------ widok odtwarzacza
    private class PlayerView extends View {
        MediaHub.Track t = new MediaHub.Track();
        private final float d = getResources().getDisplayMetrics().density;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint tx = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private int pressed = -1;
        private boolean seeking;
        private float seekFrac;
        private float barL, barR, barY;
        private float cxCtl, ctlY;

        // cele dotyku
        static final int BACK = 0, TOP1 = 1, TOP2 = 2, PREV = 3, PLAY = 4, NEXT = 5, BAR = 6,
                SHUF = 7, REP = 8, STAR = 9, MORE = 10;

        PlayerView(Context c) {
            super(c);
        }

        private float sp(float v) {
            return v * getResources().getDisplayMetrics().scaledDensity;
        }

        private float[] box(int id) {
            float w = getWidth();
            float hh = getHeight();
            switch (id) {
                case BACK:
                    return new float[]{14 * d, 12 * d, 62 * d, 60 * d};
                case TOP1:
                    return new float[]{w - 112 * d, 12 * d, w - 64 * d, 60 * d};
                case TOP2:
                    return new float[]{w - 58 * d, 12 * d, w - 10 * d, 60 * d};
                case PREV:
                    return new float[]{cxCtl - 138 * d, ctlY - 36 * d, cxCtl - 58 * d, ctlY + 36 * d};
                case PLAY:
                    return new float[]{cxCtl - 46 * d, ctlY - 46 * d, cxCtl + 46 * d, ctlY + 46 * d};
                case NEXT:
                    return new float[]{cxCtl + 58 * d, ctlY - 36 * d, cxCtl + 138 * d, ctlY + 36 * d};
                case BAR:
                    return new float[]{barL - 10 * d, barY - 22 * d, barR + 10 * d, barY + 22 * d};
                default: {
                    float py = hh * 0.90f;
                    float c = w / 2f;
                    float[] xs = {c - 190 * d, c - 70 * d, c + 40 * d, c + 130 * d};
                    int k = id - SHUF;
                    return new float[]{xs[k], py - 28 * d, xs[k] + (k < 2 ? 110 * d : 70 * d), py + 28 * d};
                }
            }
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth();
            float hh = getHeight();
            boolean dark = true;   // tekst biały na kolorowym tle
            int fg = night ? 0xFFFFFFFF : 0xFFFFFFFF;
            int sub = 0xCCFFFFFF;
            boolean access = MediaHub.accessGranted(getContext());
            boolean data = t.hasData();

            // przyciski górne
            circle(cv, box(BACK), pressed == BACK);
            p.setColor(fg);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3f * d);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            float[] b = box(BACK);
            float bx = (b[0] + b[2]) / 2f;
            float by = (b[1] + b[3]) / 2f;
            Path chev = new Path();
            chev.moveTo(bx + 4 * d, by - 10 * d);
            chev.lineTo(bx - 5 * d, by);
            chev.lineTo(bx + 4 * d, by + 10 * d);
            cv.drawPath(chev, p);
            p.setStyle(Paint.Style.FILL);

            circle(cv, box(TOP1), pressed == TOP1);
            float[] t1 = box(TOP1);
            cv.drawBitmap(Icons.carplayMark(64, 0xFFFFFFFF), null,
                    new RectF((t1[0] + t1[2]) / 2f - 12 * d, (t1[1] + t1[3]) / 2f - 12 * d,
                            (t1[0] + t1[2]) / 2f + 12 * d, (t1[1] + t1[3]) / 2f + 12 * d), p);
            circle(cv, box(TOP2), pressed == TOP2);
            float[] t2 = box(TOP2);
            float ix = (t2[0] + t2[2]) / 2f;
            float iy = (t2[1] + t2[3]) / 2f;
            p.setColor(fg);
            cv.drawCircle(ix, iy - 8 * d, 2.6f * d, p);
            r.set(ix - 2.2f * d, iy - 2 * d, ix + 2.2f * d, iy + 10 * d);
            cv.drawRoundRect(r, 2f * d, 2f * d, p);

            // okładka po prawej
            float artSide = Math.min(hh * 0.60f, w * 0.36f);
            float artL = w - 28 * d - artSide;
            float artT = hh * 0.17f;
            r.set(artL, artT, artL + artSide, artT + artSide);
            if (t.art != null) {
                Bitmap bm = t.art;
                BitmapShader sh = new BitmapShader(bm, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                Matrix m = new Matrix();
                float sc = Math.max(artSide / bm.getWidth(), artSide / bm.getHeight());
                m.setScale(sc, sc);
                m.postTranslate(artL - (bm.getWidth() * sc - artSide) / 2f,
                        artT - (bm.getHeight() * sc - artSide) / 2f);
                sh.setLocalMatrix(m);
                p.setShader(sh);
                cv.drawRoundRect(r, 20 * d, 20 * d, p);
                p.setShader(null);
            } else {
                PlayGlyphs.artPlaceholder(cv, r, 20 * d, true);
            }

            // teksty po lewej
            float tl = 28 * d;
            float maxW = artL - 24 * d - tl;
            String title;
            String artist;
            String album;
            if (!access) {
                title = "Włącz dostęp do powiadomień";
                artist = "Dotknij tutaj, aby otworzyć ustawienia Androida";
                album = "";
            } else if (!data) {
                title = "Odtwarzanie wyłączone";
                artist = "Uruchom muzykę w CarPlay (DiPlay)";
                album = "";
            } else {
                title = t.title.length() > 0 ? t.title : "Odtwarzane";
                artist = t.artist;
                album = t.album;
            }
            tx.setTextAlign(Paint.Align.LEFT);
            tx.setTypeface(Typeface.DEFAULT_BOLD);
            tx.setTextSize(sp(30));
            tx.setColor(fg);
            cv.drawText(TextUtils.ellipsize(title, tx, maxW, TextUtils.TruncateAt.END).toString(),
                    tl, hh * 0.28f, tx);
            tx.setTypeface(Typeface.DEFAULT);
            tx.setTextSize(sp(22));
            tx.setColor(sub);
            cv.drawText(TextUtils.ellipsize(artist, tx, maxW, TextUtils.TruncateAt.END).toString(),
                    tl, hh * 0.28f + 34 * d, tx);
            tx.setTextSize(sp(18));
            tx.setColor(0x99FFFFFF);
            cv.drawText(TextUtils.ellipsize(album, tx, maxW, TextUtils.TruncateAt.END).toString(),
                    tl, hh * 0.28f + 62 * d, tx);

            // sterowanie
            cxCtl = tl + maxW / 2f;
            ctlY = hh * 0.60f;
            boolean on = access && data;
            p.setColor(0xFFFFFFFF);
            p.setAlpha(on ? (pressed == PREV ? 140 : 255) : 90);
            PlayGlyphs.skip(cv, cxCtl - 98 * d, ctlY, 46 * d, false, p);
            p.setColor(0xFFFFFFFF);
            p.setAlpha(on ? (pressed == NEXT ? 140 : 255) : 90);
            PlayGlyphs.skip(cv, cxCtl + 98 * d, ctlY, 46 * d, true, p);
            p.setColor(0xFFFFFFFF);
            p.setAlpha(on ? (pressed == PLAY ? 140 : 255) : 90);
            if (t.playing()) {
                PlayGlyphs.pause(cv, cxCtl, ctlY, 66 * d, p);
            } else {
                PlayGlyphs.play(cv, cxCtl, ctlY, 66 * d, p);
            }
            p.setAlpha(255);

            // pasek postępu z czasem po bokach
            barY = hh * 0.78f;
            barL = tl + 58 * d;
            barR = w - 28 * d - 66 * d;
            long dur = t.duration;
            long pos = seeking && dur > 0 ? (long) (seekFrac * dur) : t.position();
            tx.setTextSize(sp(17));
            tx.setColor(0xCCFFFFFF);
            tx.setTextAlign(Paint.Align.LEFT);
            cv.drawText(dur > 0 && data ? PlayGlyphs.time(pos) : "--:--", tl, barY + 6 * d, tx);
            tx.setTextAlign(Paint.Align.RIGHT);
            cv.drawText(dur > 0 && data ? "-" + PlayGlyphs.time(dur - pos) : "--:--",
                    w - 28 * d, barY + 6 * d, tx);
            p.setColor(0x44FFFFFF);
            r.set(barL, barY - 4 * d, barR, barY + 4 * d);
            cv.drawRoundRect(r, 4 * d, 4 * d, p);
            if (dur > 0 && data) {
                float f = Math.max(0f, Math.min(1f, pos / (float) dur));
                p.setColor(0xEEFFFFFF);
                r.set(barL, barY - 4 * d, barL + (barR - barL) * f, barY + 4 * d);
                cv.drawRoundRect(r, 4 * d, 4 * d, p);
            }

            // dolne przyciski (dostępne tylko, gdy odtwarzacz je udostępnia)
            drawPill(cv, SHUF, MediaHub.get().findCustom("shuffle") != null);
            drawPill(cv, REP, MediaHub.get().findCustom("repeat") != null);
            drawRound(cv, STAR, hasStar());
            drawRound(cv, MORE, true);
            float[] s = box(SHUF);
            float[] rp = box(REP);
            float[] st = box(STAR);
            float[] mo = box(MORE);
            glyphShuffle(cv, (s[0] + s[2]) / 2f, (s[1] + s[3]) / 2f);
            glyphRepeat(cv, (rp[0] + rp[2]) / 2f, (rp[1] + rp[3]) / 2f);
            glyphStar(cv, (st[0] + st[2]) / 2f, (st[1] + st[3]) / 2f);
            p.setColor(0xFFFFFFFF);
            float mx = (mo[0] + mo[2]) / 2f;
            float my = (mo[1] + mo[3]) / 2f;
            for (int i = -1; i <= 1; i++) cv.drawCircle(mx + i * 9 * d, my, 2.6f * d, p);
        }

        private boolean hasStar() {
            MediaHub hub = MediaHub.get();
            return hub.findCustom("like") != null || hub.findCustom("favorite") != null
                    || hub.findCustom("star") != null;
        }

        private void circle(Canvas cv, float[] b, boolean press) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(press ? 0x88000000 : 0x55000000);
            cv.drawCircle((b[0] + b[2]) / 2f, (b[1] + b[3]) / 2f, (b[2] - b[0]) / 2f, p);
        }

        private void drawPill(Canvas cv, int id, boolean enabled) {
            float[] b = box(id);
            p.setStyle(Paint.Style.FILL);
            p.setColor(enabled ? 0x66FFFFFF : 0x33FFFFFF);
            if (pressed == id) p.setColor(0x88FFFFFF);
            r.set(b[0], b[1], b[2], b[3]);
            cv.drawRoundRect(r, 28 * d, 28 * d, p);
        }

        private void drawRound(Canvas cv, int id, boolean enabled) {
            float[] b = box(id);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x00000000);
            if (pressed == id) {
                p.setColor(0x44FFFFFF);
                cv.drawCircle((b[0] + b[2]) / 2f, (b[1] + b[3]) / 2f, 28 * d, p);
            }
        }

        private void glyphShuffle(Canvas cv, float x, float y) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.6f * d);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(MediaHub.get().findCustom("shuffle") != null ? 0xFFFFFFFF : 0x99FFFFFF);
            cv.drawLine(x - 14 * d, y - 8 * d, x + 12 * d, y + 8 * d, p);
            cv.drawLine(x - 14 * d, y + 8 * d, x + 12 * d, y - 8 * d, p);
            cv.drawLine(x + 12 * d, y - 8 * d, x + 7 * d, y - 8 * d, p);
            cv.drawLine(x + 12 * d, y + 8 * d, x + 7 * d, y + 8 * d, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void glyphRepeat(Canvas cv, float x, float y) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.6f * d);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(MediaHub.get().findCustom("repeat") != null ? 0xFFFFFFFF : 0x99FFFFFF);
            r.set(x - 14 * d, y - 8 * d, x + 14 * d, y + 8 * d);
            cv.drawRoundRect(r, 8 * d, 8 * d, p);
            p.setStyle(Paint.Style.FILL);
        }

        private void glyphStar(Canvas cv, float x, float y) {
            Path s = new Path();
            for (int i = 0; i < 10; i++) {
                double a = -Math.PI / 2 + i * Math.PI / 5;
                float rr = (i % 2 == 0 ? 15 : 6.5f) * d;
                float px = x + (float) (Math.cos(a) * rr);
                float py = y + (float) (Math.sin(a) * rr);
                if (i == 0) {
                    s.moveTo(px, py);
                } else {
                    s.lineTo(px, py);
                }
            }
            s.close();
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * d);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(hasStar() ? 0xFFFFFFFF : 0x99FFFFFF);
            cv.drawPath(s, p);
            p.setStyle(Paint.Style.FILL);
        }

        private int hit(float x, float y) {
            int[] ids = {BACK, TOP1, TOP2, PREV, PLAY, NEXT, BAR, SHUF, REP, STAR, MORE};
            for (int id : ids) {
                float[] b = box(id);
                if (x >= b[0] && x <= b[2] && y >= b[1] && y <= b[3]) return id;
            }
            // dotknięcie tekstu przy braku dostępu otwiera ustawienia
            if (y > getHeight() * 0.15f && y < getHeight() * 0.42f && x < getWidth() * 0.55f) return 99;
            return -1;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            float x = e.getX();
            float y = e.getY();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pressed = hit(x, y);
                    if (pressed == BAR && MediaHub.get().canSeek() && t.duration > 0) {
                        seeking = true;
                        seekFrac = frac(x);
                    }
                    invalidate();
                    return pressed >= 0;
                case MotionEvent.ACTION_MOVE:
                    if (seeking) {
                        seekFrac = frac(x);
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    int id = pressed;
                    pressed = -1;
                    if (seeking) {
                        seeking = false;
                        MediaHub.get().seekTo((long) (seekFrac * t.duration));
                    } else if (id >= 0 && id == hit(x, y)) {
                        act(id);
                    }
                    invalidate();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    pressed = -1;
                    seeking = false;
                    invalidate();
                    return true;
                default:
                    return true;
            }
        }

        private float frac(float x) {
            return Math.max(0f, Math.min(1f, (x - barL) / (barR - barL)));
        }

        private void act(int id) {
            Context c = getContext();
            boolean access = MediaHub.accessGranted(c);
            if (id == BACK) {
                finish();
            } else if (id == TOP1) {
                openPlayerApp();
            } else if (id == TOP2) {
                showInfo();
            } else if (id == 99) {
                if (!access) NowPlayingCard.openAccessSettings(c);
            } else if (!access) {
                NowPlayingCard.openAccessSettings(c);
            } else if (id == PREV) {
                MediaHub.get().prev();
            } else if (id == PLAY) {
                MediaHub.get().toggle();
            } else if (id == NEXT) {
                MediaHub.get().next();
            } else if (id == BAR) {
                if (!MediaHub.get().canSeek()) {
                    Toast.makeText(c, "Ten odtwarzacz nie pozwala na przewijanie", Toast.LENGTH_SHORT).show();
                }
            } else if (id == SHUF) {
                custom("shuffle", "Losowa kolejność");
            } else if (id == REP) {
                custom("repeat", "Powtarzanie");
            } else if (id == STAR) {
                if (MediaHub.get().findCustom("like") != null) {
                    custom("like", "Polubienie");
                } else if (MediaHub.get().findCustom("favorite") != null) {
                    custom("favorite", "Ulubione");
                } else {
                    custom("star", "Ulubione");
                }
            } else if (id == MORE) {
                openPlayerApp();
            }
        }

        private void custom(String word, String label) {
            PlaybackState.CustomAction a = MediaHub.get().findCustom(word);
            if (a == null) {
                Toast.makeText(getContext(), label + ": niedostępne w tym odtwarzaczu",
                        Toast.LENGTH_SHORT).show();
            } else {
                MediaHub.get().sendCustom(a);
            }
        }
    }

    private void openPlayerApp() {
        try {
            String pkg = MediaHub.get().current().pkg;
            if (pkg.length() == 0) pkg = Prefs.diplayPkg(this);
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } else {
                Toast.makeText(this, "Nie znaleziono aplikacji odtwarzacza", Toast.LENGTH_SHORT).show();
            }
        } catch (Throwable ignored) {
        }
    }

    private void showInfo() {
        TextView t = new TextView(this);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(13);
        t.setTextColor(Popups.txt(night));
        t.setPadding(Ui.dp(this, 18), Ui.dp(this, 14), Ui.dp(this, 18), Ui.dp(this, 14));
        t.setText(MediaHub.describe(this));
        Popups.panel(this, t, 560, android.view.Gravity.CENTER).show();
    }
}
