package pl.dock.widget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public class StatusService extends Service {

    private static final String CHANNEL = "dock_status";
    private static final long TICK = 20000;
    private BroadcastReceiver receiver;
    private BroadcastReceiver bcastReceiver;
    private long lastBattery = 0;
    private Handler handler;
    private Runnable tick;

    public static void start(Context c) {
        try {
            Intent i = new Intent(c, StatusService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                c.startForegroundService(i);
            } else {
                c.startService(i);
            }
        } catch (Exception ignored) {
        }
    }

    public static void restart(Context c) {
        try {
            c.stopService(new Intent(c, StatusService.class));
        } catch (Exception ignored) {
        }
        start(c);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        goForeground();
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                    long now = System.currentTimeMillis();
                    if (now - lastBattery < 5000) return;
                    lastBattery = now;
                }
                DockWidget.updateAll(context);
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        f.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        f.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        f.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        f.addAction("android.net.wifi.WIFI_AP_STATE_CHANGED");
        f.addAction("android.net.conn.TETHER_STATE_CHANGED");
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(Intent.ACTION_CONFIGURATION_CHANGED);
        registerReceiver(receiver, f);

        // własny broadcast z napięciem (jeśli wybrany w ustawieniach)
        String action = Prefs.bcastAction(this);
        if (action.length() > 0) {
            bcastReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context ctx, Intent intent) {
                    try {
                        Bundle ex = intent.getExtras();
                        String name = Prefs.bcastExtra(ctx);
                        if (ex != null && name.length() > 0 && ex.containsKey(name)) {
                            @SuppressWarnings("deprecation")
                            Object o = ex.get(name);
                            Double d = Volt.toDouble(o);
                            if (d != null) Prefs.setBcastVal(ctx, d.floatValue());
                        }
                    } catch (Throwable ignored) {
                    }
                    DockWidget.updateAll(ctx);
                }
            };
            registerReceiver(bcastReceiver, new IntentFilter(action));
        }

        // odświeżanie co 20 s (napięcie, statusy bez powiadomień)
        handler = new Handler(Looper.getMainLooper());
        tick = new Runnable() {
            @Override
            public void run() {
                DockWidget.updateAll(StatusService.this);
                handler.postDelayed(this, TICK);
            }
        };
        handler.postDelayed(tick, TICK);
    }

    private void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "Dock", NotificationManager.IMPORTANCE_MIN));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("Dock");
        startForeground(1, b.build());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground();
        DockWidget.updateAll(this);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            if (handler != null && tick != null) handler.removeCallbacks(tick);
            unregisterReceiver(receiver);
            if (bcastReceiver != null) unregisterReceiver(bcastReceiver);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
